﻿namespace FLSHOP
{
    partial class goodsOnSaleView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_type_good = new System.Windows.Forms.TextBox();
            this.textBox_num = new System.Windows.Forms.TextBox();
            this.textBox_name_good = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.name_flower = new System.Windows.Forms.Label();
            this.color = new System.Windows.Forms.Label();
            this.flower_id = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.search = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_save = new System.Windows.Forms.Button();
            this.button_newWrite = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.clos = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.clos);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(680, 680);
            this.panel2.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox_type_good);
            this.panel1.Controls.Add(this.textBox_num);
            this.panel1.Controls.Add(this.textBox_name_good);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.name_flower);
            this.panel1.Controls.Add(this.color);
            this.panel1.Controls.Add(this.flower_id);
            this.panel1.Location = new System.Drawing.Point(12, 392);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 261);
            this.panel1.TabIndex = 37;
            // 
            // textBox_type_good
            // 
            this.textBox_type_good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_type_good.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_type_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_type_good.Location = new System.Drawing.Point(223, 110);
            this.textBox_type_good.Name = "textBox_type_good";
            this.textBox_type_good.Size = new System.Drawing.Size(209, 28);
            this.textBox_type_good.TabIndex = 12;
            this.textBox_type_good.TextChanged += new System.EventHandler(this.textBox_type_good_TextChanged);
            // 
            // textBox_num
            // 
            this.textBox_num.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_num.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_num.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_num.Location = new System.Drawing.Point(223, 135);
            this.textBox_num.Name = "textBox_num";
            this.textBox_num.Size = new System.Drawing.Size(209, 28);
            this.textBox_num.TabIndex = 11;
            this.textBox_num.TextChanged += new System.EventHandler(this.textBox_num_TextChanged);
            // 
            // textBox_name_good
            // 
            this.textBox_name_good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_name_good.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name_good.Location = new System.Drawing.Point(223, 85);
            this.textBox_name_good.Name = "textBox_name_good";
            this.textBox_name_good.Size = new System.Drawing.Size(209, 28);
            this.textBox_name_good.TabIndex = 9;
            this.textBox_name_good.TextChanged += new System.EventHandler(this.textBox_name_good_TextChanged);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(172, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Запись";
            // 
            // name_flower
            // 
            this.name_flower.AutoSize = true;
            this.name_flower.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_flower.Location = new System.Drawing.Point(20, 117);
            this.name_flower.Name = "name_flower";
            this.name_flower.Size = new System.Drawing.Size(89, 21);
            this.name_flower.TabIndex = 6;
            this.name_flower.Text = "Тип товара";
            // 
            // color
            // 
            this.color.AutoSize = true;
            this.color.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.color.Location = new System.Drawing.Point(20, 142);
            this.color.Name = "color";
            this.color.Size = new System.Drawing.Size(184, 21);
            this.color.TabIndex = 5;
            this.color.Text = "Актуальное количество";
            // 
            // flower_id
            // 
            this.flower_id.AutoSize = true;
            this.flower_id.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flower_id.Location = new System.Drawing.Point(20, 92);
            this.flower_id.Name = "flower_id";
            this.flower_id.Size = new System.Drawing.Size(133, 21);
            this.flower_id.TabIndex = 0;
            this.flower_id.Text = "Название товара";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Controls.Add(this.search);
            this.panel4.Location = new System.Drawing.Point(12, 26);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(172, 35);
            this.panel4.TabIndex = 36;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FLSHOP.Properties.Resources._370082_find_search_zoom_magnifier_view_icon;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(27, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.search.Location = new System.Drawing.Point(36, 4);
            this.search.Multiline = true;
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(128, 22);
            this.search.TabIndex = 24;
            this.search.TextChanged += new System.EventHandler(this.search_TextChanged);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button2);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.button_delete);
            this.panel3.Controls.Add(this.button_update);
            this.panel3.Controls.Add(this.button_save);
            this.panel3.Controls.Add(this.button_newWrite);
            this.panel3.Location = new System.Drawing.Point(480, 392);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(188, 261);
            this.panel3.TabIndex = 35;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(20, 92);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 33);
            this.button2.TabIndex = 18;
            this.button2.Text = "Обновить";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(29, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "Управление";
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_delete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_delete.Location = new System.Drawing.Point(20, 179);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(150, 33);
            this.button_delete.TabIndex = 16;
            this.button_delete.Text = "Удалить";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_update.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_update.Location = new System.Drawing.Point(20, 135);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(150, 33);
            this.button_update.TabIndex = 15;
            this.button_update.Text = "Изменить";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(20, 222);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 14;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_newWrite
            // 
            this.button_newWrite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_newWrite.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_newWrite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_newWrite.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_newWrite.Location = new System.Drawing.Point(20, 47);
            this.button_newWrite.Name = "button_newWrite";
            this.button_newWrite.Size = new System.Drawing.Size(150, 33);
            this.button_newWrite.TabIndex = 13;
            this.button_newWrite.Text = "Новая запись";
            this.button_newWrite.UseVisualStyleBackColor = false;
            this.button_newWrite.Click += new System.EventHandler(this.button_newWrite_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(87, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(507, 277);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(651, 0);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // goodsOnSaleView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 680);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "goodsOnSaleView";
            this.Text = "goodsOnSaleView";
            this.Load += new System.EventHandler(this.goodsOnSaleView_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_type_good;
        private System.Windows.Forms.TextBox textBox_num;
        private System.Windows.Forms.TextBox textBox_name_good;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label name_flower;
        private System.Windows.Forms.Label color;
        private System.Windows.Forms.Label flower_id;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox search;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_newWrite;
    }
}