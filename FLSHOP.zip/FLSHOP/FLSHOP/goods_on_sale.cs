﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class goods_on_sale : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;
        public goods_on_sale()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            try
            {
                sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Goods_on_sale]", sqlconn);

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Goods_on_sale");

                dataGridView1.DataSource = dataset.Tables["Goods_on_sale"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            try
            {
                dataset.Tables["Goods_on_sale"].Clear();

                sqldataadapter.Fill(dataset, "Goods_on_sale");

                dataGridView1.DataSource = dataset.Tables["Goods_on_sale"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void goods_on_sale_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 4)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();

                    if (task == "DELETE")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);

                            dataset.Tables["Goods_on_sale"].Rows[rowIndex].Delete();

                            sqldataadapter.Update(dataset, "Goods_on_sale");
                        }
                    }
                    else if (task == "INSERT")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;
                        DataRow row = dataset.Tables["Goods_on_sale"].NewRow();

                        row["ID_good"] = dataGridView1.Rows[rowIndex].Cells["ID_good"].Value;
                        row["Type_good"] = dataGridView1.Rows[rowIndex].Cells["Type_good"].Value;
                        row["Number_of_goods"] = dataGridView1.Rows[rowIndex].Cells["Number_of_goods"].Value;
                        row["Price"] = dataGridView1.Rows[rowIndex].Cells["Price"].Value;

                        dataset.Tables["Goods_on_sale"].Rows.Add(row);
                        dataset.Tables["Goods_on_sale"].Rows.RemoveAt(dataset.Tables["Goods_on_sale"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "DELETE";

                        sqldataadapter.Update(dataset, "Goods_on_sale");
                        newRoading = false;
                    }
                    else if (task == "UPDATE")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Goods_on_sale"].Rows[r]["ID_good"] = dataGridView1.Rows[r].Cells["ID_good"].Value;
                        dataset.Tables["Goods_on_sale"].Rows[r]["Type_good"] = dataGridView1.Rows[r].Cells["Type_good"].Value;
                        dataset.Tables["Goods_on_sale"].Rows[r]["Number_of_goods"] = dataGridView1.Rows[r].Cells["Number_of_goods"].Value;
                        dataset.Tables["Goods_on_sale"].Rows[r]["Price"] = dataGridView1.Rows[r].Cells["Price"].Value;

                        sqldataadapter.Update(dataset, "Goods_on_sale");
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "DELETE";

                    }
                    ReloadData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    newRoading = true;
                    int lastRow = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRow];
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[4, lastRow] = linkcell;

                    row.Cells["Command"].Value = "INSERT";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[4, rowIndex] = linkcell;

                    editingrow.Cells["Command"].Value = "UPDATE";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
                Application.Exit();
            }
        }
    }
}
