﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class flowers : Form
    {
        int selectedRow;
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        private bool newRoading = false;
        public flowers()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            try
            {
                if (authorization.testOnClickBut != true)
                {

                    sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Flowers]", sqlconn);


                    sqlbuild = new SqlCommandBuilder(sqldataadapter);
                    sqlbuild.GetInsertCommand();
                    sqlbuild.GetUpdateCommand();
                    sqlbuild.GetDeleteCommand();

                    dataset = new DataSet();
                    sqldataadapter.Fill(dataset, "Flowers");

                    dataGridView1.DataSource = dataset.Tables["Flowers"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[5, i] = linkcell;
                    }
                }
                else
                {
                    sqldataadapter = new SqlDataAdapter("SELECT * FROM [Flowers]", sqlconn);
                    sqlbuild = new SqlCommandBuilder(sqldataadapter);
                    sqlbuild.GetInsertCommand();
                    sqlbuild.GetUpdateCommand();
                    sqlbuild.GetDeleteCommand();

                    dataset = new DataSet();
                    sqldataadapter.Fill(dataset, "Flowers");

                    dataGridView1.DataSource = dataset.Tables["Flowers"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[4, i] = linkcell;
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    dataset.Tables["Flowers"].Clear();

                    sqldataadapter.Fill(dataset, "Flowers");

                    dataGridView1.DataSource = dataset.Tables["Flowers"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[5, i] = linkcell;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("FlowerID", "ID");
            dataGridView1.Columns.Add("Name_flower", "Название цветка");
            dataGridView1.Columns.Add("Color", "Цвет");
            dataGridView1.Columns.Add("Actual_availability", "Актуальное количество");
            dataGridView1.Columns.Add("Price", "Цена");

        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2),
                          record.GetValue(3),
                          record.GetValue(4));

        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = "SELECT * FROM Flowers";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }

        private void flowers_Load(object sender, EventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                panel1.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;

                button1.Visible = false;
                CreateColums();
                RefreshDataGrid(dataGridView1);

            }
            else
            {
                panel1.Visible = false;
                panel3.Visible = false;
                panel4.Visible = false;

                button1.Visible = true;


                string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
                sqlconn = new SqlConnection(connectionString);
                sqlconn.Open();
                LoadData();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    if (e.ColumnIndex == 5)
                    {
                        string task = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();

                        if (task == "DELETE")
                        {
                            if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                int rowIndex = e.RowIndex;

                                dataGridView1.Rows.RemoveAt(rowIndex);

                                dataset.Tables["Flowers"].Rows[rowIndex].Delete();

                                sqldataadapter.Update(dataset, "Flowers");
                            }
                        }
                        else if (task == "INSERT")
                        {
                            int rowIndex = dataGridView1.Rows.Count - 2;
                            DataRow row = dataset.Tables["Flowers"].NewRow();

                            row["Name_flower"] = dataGridView1.Rows[rowIndex].Cells["Name_flower"].Value;
                            row["Color"] = dataGridView1.Rows[rowIndex].Cells["Color"].Value;
                            row["Actual_availability"] = dataGridView1.Rows[rowIndex].Cells["Actual_availability"].Value;
                            row["Price"] = dataGridView1.Rows[rowIndex].Cells["Price"].Value;

                            dataset.Tables["Flowers"].Rows.Add(row);
                            dataset.Tables["Flowers"].Rows.RemoveAt(dataset.Tables["Flowers"].Rows.Count - 1);
                            dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";

                            sqldataadapter.Update(dataset, "Flowers");
                            newRoading = false;
                        }
                        else if (task == "UPDATE")
                        {
                            int r = e.RowIndex;
                            dataset.Tables["Flowers"].Rows[r]["Name_flower"] = dataGridView1.Rows[r].Cells["Name_flower"].Value;
                            dataset.Tables["Flowers"].Rows[r]["Color"] = dataGridView1.Rows[r].Cells["Color"].Value;
                            dataset.Tables["Flowers"].Rows[r]["Actual_availability"] = dataGridView1.Rows[r].Cells["Actual_availability"].Value;
                            dataset.Tables["Flowers"].Rows[r]["Price"] = dataGridView1.Rows[r].Cells["Price"].Value;

                            sqldataadapter.Update(dataset, "Flowers");
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";

                        }
                        ReloadData();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    if (newRoading == false)
                    {
                        newRoading = true;
                        int lastRow = dataGridView1.Rows.Count - 2;

                        DataGridViewRow row = dataGridView1.Rows[lastRow];
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[5, lastRow] = linkcell;

                        row.Cells["Command"].Value = "INSERT";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    if (newRoading == false)
                    {
                        int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                        DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[5, rowIndex] = linkcell;

                        editingrow.Cells["Command"].Value = "UPDATE";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }


        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

            connection.Open();
            SqlCommand com = new SqlCommand(searchString, connection);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();


        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            string searchString = @"SELECT * FROM Flowers WHERE CONCAT(FlowerID, Name_flower, Color, Actual_availability, Price)  LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void textBox_id_flower_TextChanged(object sender, EventArgs e)
        {
            textBox_id_flower.ReadOnly = true;
        }

        private void textBox_name_flower_TextChanged(object sender, EventArgs e)
        {
            textBox_name_flower.ReadOnly = true;

        }

        private void textBox_color_TextChanged(object sender, EventArgs e)
        {
            textBox_color.ReadOnly = true;

        }

        private void textBox_numbers_of_TextChanged(object sender, EventArgs e)
        {
            textBox_numbers_of.ReadOnly = true;

        }

        private void textBox_price_TextChanged(object sender, EventArgs e)
        {
            textBox_price.ReadOnly = true;

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                selectedRow = e.RowIndex;
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[selectedRow];
                    textBox_id_flower.Text = row.Cells[0].Value.ToString();
                    textBox_name_flower.Text = row.Cells[1].Value.ToString();
                    textBox_color.Text = row.Cells[2].Value.ToString();
                    textBox_numbers_of.Text = row.Cells[3].Value.ToString();
                    textBox_price.Text = row.Cells[4].Value.ToString();
                }
            }
        }
        private void ClearFields()
        {
            textBox_color.Text = "";
            textBox_id_flower.Text = "";
            textBox_numbers_of.Text = "";
            textBox_price.Text = "";
            textBox_name_flower.Text = "";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ClearFields();
            RefreshDataGrid(dataGridView1);

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
