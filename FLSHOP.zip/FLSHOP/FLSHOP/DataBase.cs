﻿namespace FLSHOP
{
    internal class DataBase
    {
    }
}