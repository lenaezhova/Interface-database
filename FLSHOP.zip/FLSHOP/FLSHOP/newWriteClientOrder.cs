﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class newWriteClientOrder : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public newWriteClientOrder()
        {
            InitializeComponent();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State != ConnectionState.Closed) connection.Close();
            this.Hide();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            connection.Open();

            var surname = textBox_surname_client.Text;
            var name = textBox_name_client.Text;
            var phone_number = textBox_phone_number.Text;
            var date_order = textBox_date_order.Text;

            var addQuery = $"INSERT INTO ClientDataOrderEmployee (Surname, Name, Phone_number, Date_order) VALUES ('{surname}', '{name}', '{phone_number}', '{date_order}')";
            var command = new SqlCommand(addQuery, connection);
            command.ExecuteNonQuery();
            this.Hide();
            MessageBox.Show("Запись успешно создана!", "Нажмите OK, чтобы продолжить", MessageBoxButtons.OK, MessageBoxIcon.Information);
            connection.Close();

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void surname_client_Click(object sender, EventArgs e)
        {

        }
    }
}
