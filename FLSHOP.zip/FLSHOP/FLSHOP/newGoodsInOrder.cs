﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class newGoodsInOrder : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public newGoodsInOrder()
        {
            InitializeComponent();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State != ConnectionState.Closed) connection.Close();
            this.Hide();
        }

        private void button_add_Click(object sender, EventArgs e)
        {
            connection.Open();

            var name = textBox_name_good.Text;
            var type = textBox_type_good.Text;
            var num = textBox_numbers.Text;

            var addQuery = $"INSERT INTO goodsInTheOrder (ID_order, Name_good, Type_of, Number_of_goods) VALUES ('{numberfOrder.id_order}', '{name}', '{type}', '{num}')";
            var command = new SqlCommand(addQuery, connection);
            command.ExecuteNonQuery();
            MessageBox.Show("Товар успешно добавлен!", "Нажмите OK, чтобы продолжить", MessageBoxButtons.OK, MessageBoxIcon.Information);
            connection.Close();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            this.Hide();
            MessageBox.Show("Товары в заказ успешно добавлены!", "Нажмите OK, чтобы продолжить", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
