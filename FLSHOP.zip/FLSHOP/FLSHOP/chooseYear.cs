﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class chooseYear : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public chooseYear()
        {
            InitializeComponent();
        }

        private void textBox_surname_client_TextChanged(object sender, EventArgs e)
        {

        }
        //safronchikmi @yandex.ru
        private void button_save_Click(object sender, EventArgs e)
        {
            connection.Open();
            SqlCommand command = new SqlCommand("moneyOfYear", connection);

            command.CommandType = CommandType.StoredProcedure;

            command.Parameters.Add(new SqlParameter("@operation", SqlDbType.Int));
            command.Parameters.Add(new SqlParameter("@year", SqlDbType.Int));

            command.Parameters["@operation"].Value = user.reportFor;
            command.Parameters["@year"].Value = Convert.ToInt32(textBox_year.Text);

            //var retValue = command.Parameters.Add("@money1", SqlDbType.Int);
            var retValue = new SqlParameter("@money1", SqlDbType.Int);


            retValue.Direction = ParameterDirection.Output;
            command.Parameters.Add(retValue);

            command.ExecuteNonQuery();
            var res = retValue.Value.ToString();

            textBox_res.Text = res;

            connection.Close();

        }

        private void clos_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void chooseYear_Load(object sender, EventArgs e)
        {
            if (user.reportFor == 1)
            {
                label9.Text = "Введите год, за который \r\nтребуется вывести выручку:";

            }
            if (user.reportFor == 2)
            {
                label9.Text = "Введите год, за который \r\nтребуется вывести затраты:";

            }
        
            if (user.reportFor == 3)
            {
                label9.Text = "Введите год, за который \r\nтребуется вывести прибыль:";

            }
}

        private void textBox_res_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
