﻿namespace FLSHOP
{
    partial class newGoodsInOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_add = new System.Windows.Forms.Button();
            this.name_good = new System.Windows.Forms.Label();
            this.type_good = new System.Windows.Forms.Label();
            this.numbers_of = new System.Windows.Forms.Label();
            this.button_save = new System.Windows.Forms.Button();
            this.textBox_numbers = new System.Windows.Forms.TextBox();
            this.clos = new System.Windows.Forms.Label();
            this.textBox_name_good = new System.Windows.Forms.TextBox();
            this.textBox_type_good = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.button_add);
            this.panel1.Controls.Add(this.name_good);
            this.panel1.Controls.Add(this.type_good);
            this.panel1.Controls.Add(this.numbers_of);
            this.panel1.Controls.Add(this.button_save);
            this.panel1.Controls.Add(this.textBox_numbers);
            this.panel1.Controls.Add(this.clos);
            this.panel1.Controls.Add(this.textBox_name_good);
            this.panel1.Controls.Add(this.textBox_type_good);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 307);
            this.panel1.TabIndex = 19;
            // 
            // button_add
            // 
            this.button_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_add.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add.Location = new System.Drawing.Point(155, 219);
            this.button_add.Name = "button_add";
            this.button_add.Size = new System.Drawing.Size(150, 33);
            this.button_add.TabIndex = 21;
            this.button_add.Text = "Добавить";
            this.button_add.UseVisualStyleBackColor = false;
            this.button_add.Click += new System.EventHandler(this.button_add_Click);
            // 
            // name_good
            // 
            this.name_good.AutoSize = true;
            this.name_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name_good.Location = new System.Drawing.Point(22, 100);
            this.name_good.Name = "name_good";
            this.name_good.Size = new System.Drawing.Size(133, 21);
            this.name_good.TabIndex = 20;
            this.name_good.Text = "Название товара";
            // 
            // type_good
            // 
            this.type_good.AutoSize = true;
            this.type_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.type_good.Location = new System.Drawing.Point(22, 125);
            this.type_good.Name = "type_good";
            this.type_good.Size = new System.Drawing.Size(89, 21);
            this.type_good.TabIndex = 19;
            this.type_good.Text = "Тип товара";
            // 
            // numbers_of
            // 
            this.numbers_of.AutoSize = true;
            this.numbers_of.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numbers_of.Location = new System.Drawing.Point(22, 150);
            this.numbers_of.Name = "numbers_of";
            this.numbers_of.Size = new System.Drawing.Size(97, 21);
            this.numbers_of.TabIndex = 18;
            this.numbers_of.Text = "Количество";
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(155, 258);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 17;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // textBox_numbers
            // 
            this.textBox_numbers.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_numbers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_numbers.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_numbers.Location = new System.Drawing.Point(228, 148);
            this.textBox_numbers.Name = "textBox_numbers";
            this.textBox_numbers.Size = new System.Drawing.Size(209, 28);
            this.textBox_numbers.TabIndex = 16;
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(420, -1);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // textBox_name_good
            // 
            this.textBox_name_good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_name_good.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name_good.Location = new System.Drawing.Point(228, 98);
            this.textBox_name_good.Name = "textBox_name_good";
            this.textBox_name_good.Size = new System.Drawing.Size(209, 28);
            this.textBox_name_good.TabIndex = 11;
            // 
            // textBox_type_good
            // 
            this.textBox_type_good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_type_good.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_type_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_type_good.Location = new System.Drawing.Point(228, 123);
            this.textBox_type_good.Name = "textBox_type_good";
            this.textBox_type_good.Size = new System.Drawing.Size(209, 28);
            this.textBox_type_good.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Candara", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(150, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 37);
            this.label9.TabIndex = 8;
            this.label9.Text = "Новая запись";
            // 
            // newGoodsInOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 307);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "newGoodsInOrder";
            this.Text = "newGoodsInOrder";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.TextBox textBox_numbers;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.TextBox textBox_name_good;
        private System.Windows.Forms.TextBox textBox_type_good;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label name_good;
        private System.Windows.Forms.Label type_good;
        private System.Windows.Forms.Label numbers_of;
        private System.Windows.Forms.Button button_add;
    }
}