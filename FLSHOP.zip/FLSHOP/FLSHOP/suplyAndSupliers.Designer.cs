﻿namespace FLSHOP
{
    partial class suplyAndSupliers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDsupplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.surnameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameofsupplierDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phonenumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.suppliersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.flower_shopDataSet4 = new FLSHOP.Flower_shopDataSet4();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.supplyIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.goodIDSupDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typegoodDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numbersDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateofsupplyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderForDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKsupplierinsupplyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.clos = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.goodIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.typegoodDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pricefromsupplierDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.daysSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fKsupplierinSuppliersAndPriceBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.suppliersTableAdapter = new FLSHOP.Flower_shopDataSet4TableAdapters.SuppliersTableAdapter();
            this.supplyTableAdapter = new FLSHOP.Flower_shopDataSet4TableAdapters.SupplyTableAdapter();
            this.suppliersAndPriceDaysTableAdapter = new FLSHOP.Flower_shopDataSet4TableAdapters.SuppliersAndPriceDaysTableAdapter();
            this.name_bouq = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flower_shopDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKsupplierinsupplyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKsupplierinSuppliersAndPriceBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDsupplierDataGridViewTextBoxColumn,
            this.surnameDataGridViewTextBoxColumn,
            this.nameofsupplierDataGridViewTextBoxColumn,
            this.phonenumberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.suppliersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(69, 70);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(507, 277);
            this.dataGridView1.TabIndex = 13;
            // 
            // iDsupplierDataGridViewTextBoxColumn
            // 
            this.iDsupplierDataGridViewTextBoxColumn.DataPropertyName = "ID_supplier";
            this.iDsupplierDataGridViewTextBoxColumn.HeaderText = "ID поставщика";
            this.iDsupplierDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.iDsupplierDataGridViewTextBoxColumn.Name = "iDsupplierDataGridViewTextBoxColumn";
            this.iDsupplierDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDsupplierDataGridViewTextBoxColumn.Width = 125;
            // 
            // surnameDataGridViewTextBoxColumn
            // 
            this.surnameDataGridViewTextBoxColumn.DataPropertyName = "Surname";
            this.surnameDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.surnameDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.surnameDataGridViewTextBoxColumn.Name = "surnameDataGridViewTextBoxColumn";
            this.surnameDataGridViewTextBoxColumn.ReadOnly = true;
            this.surnameDataGridViewTextBoxColumn.Width = 125;
            // 
            // nameofsupplierDataGridViewTextBoxColumn
            // 
            this.nameofsupplierDataGridViewTextBoxColumn.DataPropertyName = "Name_of_supplier";
            this.nameofsupplierDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.nameofsupplierDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.nameofsupplierDataGridViewTextBoxColumn.Name = "nameofsupplierDataGridViewTextBoxColumn";
            this.nameofsupplierDataGridViewTextBoxColumn.ReadOnly = true;
            this.nameofsupplierDataGridViewTextBoxColumn.Width = 125;
            // 
            // phonenumberDataGridViewTextBoxColumn
            // 
            this.phonenumberDataGridViewTextBoxColumn.DataPropertyName = "Phone_number";
            this.phonenumberDataGridViewTextBoxColumn.HeaderText = "Номер телефона";
            this.phonenumberDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.phonenumberDataGridViewTextBoxColumn.Name = "phonenumberDataGridViewTextBoxColumn";
            this.phonenumberDataGridViewTextBoxColumn.ReadOnly = true;
            this.phonenumberDataGridViewTextBoxColumn.Width = 125;
            // 
            // suppliersBindingSource
            // 
            this.suppliersBindingSource.DataMember = "Suppliers";
            this.suppliersBindingSource.DataSource = this.bindingSource1;
            // 
            // bindingSource1
            // 
            this.bindingSource1.DataSource = this.flower_shopDataSet4;
            this.bindingSource1.Position = 0;
            // 
            // flower_shopDataSet4
            // 
            this.flower_shopDataSet4.DataSetName = "Flower_shopDataSet4";
            this.flower_shopDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplyIDDataGridViewTextBoxColumn,
            this.goodIDSupDataGridViewTextBoxColumn,
            this.typegoodDataGridViewTextBoxColumn,
            this.numbersDataGridViewTextBoxColumn,
            this.dateofsupplyDataGridViewTextBoxColumn,
            this.orderForDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.fKsupplierinsupplyBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(707, 70);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(507, 277);
            this.dataGridView2.TabIndex = 14;
            // 
            // supplyIDDataGridViewTextBoxColumn
            // 
            this.supplyIDDataGridViewTextBoxColumn.DataPropertyName = "SupplyID";
            this.supplyIDDataGridViewTextBoxColumn.HeaderText = "Номер поставки";
            this.supplyIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.supplyIDDataGridViewTextBoxColumn.Name = "supplyIDDataGridViewTextBoxColumn";
            this.supplyIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.supplyIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // goodIDSupDataGridViewTextBoxColumn
            // 
            this.goodIDSupDataGridViewTextBoxColumn.DataPropertyName = "GoodIDSup";
            this.goodIDSupDataGridViewTextBoxColumn.HeaderText = "ID товара";
            this.goodIDSupDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.goodIDSupDataGridViewTextBoxColumn.Name = "goodIDSupDataGridViewTextBoxColumn";
            this.goodIDSupDataGridViewTextBoxColumn.ReadOnly = true;
            this.goodIDSupDataGridViewTextBoxColumn.Width = 125;
            // 
            // typegoodDataGridViewTextBoxColumn
            // 
            this.typegoodDataGridViewTextBoxColumn.DataPropertyName = "Type_good";
            this.typegoodDataGridViewTextBoxColumn.HeaderText = "Тип товара";
            this.typegoodDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.typegoodDataGridViewTextBoxColumn.Name = "typegoodDataGridViewTextBoxColumn";
            this.typegoodDataGridViewTextBoxColumn.ReadOnly = true;
            this.typegoodDataGridViewTextBoxColumn.Width = 125;
            // 
            // numbersDataGridViewTextBoxColumn
            // 
            this.numbersDataGridViewTextBoxColumn.DataPropertyName = "Numbers";
            this.numbersDataGridViewTextBoxColumn.HeaderText = "Количество в поставке";
            this.numbersDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.numbersDataGridViewTextBoxColumn.Name = "numbersDataGridViewTextBoxColumn";
            this.numbersDataGridViewTextBoxColumn.ReadOnly = true;
            this.numbersDataGridViewTextBoxColumn.Width = 125;
            // 
            // dateofsupplyDataGridViewTextBoxColumn
            // 
            this.dateofsupplyDataGridViewTextBoxColumn.DataPropertyName = "Date_of_supply";
            this.dateofsupplyDataGridViewTextBoxColumn.HeaderText = "Дата поставки";
            this.dateofsupplyDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.dateofsupplyDataGridViewTextBoxColumn.Name = "dateofsupplyDataGridViewTextBoxColumn";
            this.dateofsupplyDataGridViewTextBoxColumn.ReadOnly = true;
            this.dateofsupplyDataGridViewTextBoxColumn.Width = 125;
            // 
            // orderForDataGridViewTextBoxColumn
            // 
            this.orderForDataGridViewTextBoxColumn.DataPropertyName = "OrderFor";
            this.orderForDataGridViewTextBoxColumn.HeaderText = "Заказ";
            this.orderForDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.orderForDataGridViewTextBoxColumn.Name = "orderForDataGridViewTextBoxColumn";
            this.orderForDataGridViewTextBoxColumn.ReadOnly = true;
            this.orderForDataGridViewTextBoxColumn.Width = 125;
            // 
            // fKsupplierinsupplyBindingSource
            // 
            this.fKsupplierinsupplyBindingSource.DataMember = "FK_supplier_in_supply";
            this.fKsupplierinsupplyBindingSource.DataSource = this.suppliersBindingSource;
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(1256, -1);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 15;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click_1);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodIDDataGridViewTextBoxColumn,
            this.typegoodDataGridViewTextBoxColumn1,
            this.pricefromsupplierDataGridViewTextBoxColumn1,
            this.daysSDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.fKsupplierinSuppliersAndPriceBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(69, 398);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.RowTemplate.Height = 24;
            this.dataGridView3.Size = new System.Drawing.Size(507, 277);
            this.dataGridView3.TabIndex = 16;
            // 
            // goodIDDataGridViewTextBoxColumn
            // 
            this.goodIDDataGridViewTextBoxColumn.DataPropertyName = "GoodID";
            this.goodIDDataGridViewTextBoxColumn.HeaderText = "ID товара";
            this.goodIDDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.goodIDDataGridViewTextBoxColumn.Name = "goodIDDataGridViewTextBoxColumn";
            this.goodIDDataGridViewTextBoxColumn.ReadOnly = true;
            this.goodIDDataGridViewTextBoxColumn.Width = 125;
            // 
            // typegoodDataGridViewTextBoxColumn1
            // 
            this.typegoodDataGridViewTextBoxColumn1.DataPropertyName = "Type_good";
            this.typegoodDataGridViewTextBoxColumn1.HeaderText = "Тип товара";
            this.typegoodDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.typegoodDataGridViewTextBoxColumn1.Name = "typegoodDataGridViewTextBoxColumn1";
            this.typegoodDataGridViewTextBoxColumn1.ReadOnly = true;
            this.typegoodDataGridViewTextBoxColumn1.Width = 125;
            // 
            // pricefromsupplierDataGridViewTextBoxColumn1
            // 
            this.pricefromsupplierDataGridViewTextBoxColumn1.DataPropertyName = "Price_from_supplier";
            this.pricefromsupplierDataGridViewTextBoxColumn1.HeaderText = "Цена от поставщика";
            this.pricefromsupplierDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.pricefromsupplierDataGridViewTextBoxColumn1.Name = "pricefromsupplierDataGridViewTextBoxColumn1";
            this.pricefromsupplierDataGridViewTextBoxColumn1.ReadOnly = true;
            this.pricefromsupplierDataGridViewTextBoxColumn1.Width = 125;
            // 
            // daysSDataGridViewTextBoxColumn
            // 
            this.daysSDataGridViewTextBoxColumn.DataPropertyName = "DaysS";
            this.daysSDataGridViewTextBoxColumn.HeaderText = "Количество дней, необходимых для поставки";
            this.daysSDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.daysSDataGridViewTextBoxColumn.Name = "daysSDataGridViewTextBoxColumn";
            this.daysSDataGridViewTextBoxColumn.ReadOnly = true;
            this.daysSDataGridViewTextBoxColumn.Width = 125;
            // 
            // fKsupplierinSuppliersAndPriceBindingSource
            // 
            this.fKsupplierinSuppliersAndPriceBindingSource.DataMember = "FK_supplier_in_SuppliersAndPrice";
            this.fKsupplierinSuppliersAndPriceBindingSource.DataSource = this.suppliersBindingSource;
            // 
            // suppliersTableAdapter
            // 
            this.suppliersTableAdapter.ClearBeforeFill = true;
            // 
            // supplyTableAdapter
            // 
            this.supplyTableAdapter.ClearBeforeFill = true;
            // 
            // suppliersAndPriceDaysTableAdapter
            // 
            this.suppliersAndPriceDaysTableAdapter.ClearBeforeFill = true;
            // 
            // name_bouq
            // 
            this.name_bouq.AutoSize = true;
            this.name_bouq.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.name_bouq.Location = new System.Drawing.Point(235, 31);
            this.name_bouq.Name = "name_bouq";
            this.name_bouq.Size = new System.Drawing.Size(119, 24);
            this.name_bouq.TabIndex = 17;
            this.name_bouq.Text = "Поставщики";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(898, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 24);
            this.label1.TabIndex = 18;
            this.label1.Text = "Поставки";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(167, 359);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(303, 24);
            this.label2.TabIndex = 19;
            this.label2.Text = "Товары и прайсы от поставщиков";
            // 
            // suplyAndSupliers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.ClientSize = new System.Drawing.Size(1286, 687);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.name_bouq);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.clos);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "suplyAndSupliers";
            this.Text = "suplyAndSupliers";
            this.Load += new System.EventHandler(this.suplyAndSupliers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.suppliersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flower_shopDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKsupplierinsupplyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKsupplierinSuppliersAndPriceBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource bindingSource1;
        private Flower_shopDataSet4 flower_shopDataSet4;
        private System.Windows.Forms.BindingSource suppliersBindingSource;
        private Flower_shopDataSet4TableAdapters.SuppliersTableAdapter suppliersTableAdapter;
        private System.Windows.Forms.BindingSource fKsupplierinsupplyBindingSource;
        private Flower_shopDataSet4TableAdapters.SupplyTableAdapter supplyTableAdapter;
        private System.Windows.Forms.BindingSource fKsupplierinSuppliersAndPriceBindingSource;
        private Flower_shopDataSet4TableAdapters.SuppliersAndPriceDaysTableAdapter suppliersAndPriceDaysTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDsupplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn surnameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameofsupplierDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phonenumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplyIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodIDSupDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typegoodDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numbersDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateofsupplyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderForDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typegoodDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn pricefromsupplierDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn daysSDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label name_bouq;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}