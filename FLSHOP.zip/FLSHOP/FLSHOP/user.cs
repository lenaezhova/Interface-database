﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class user : Form
    {
        public static int reportFor;

        public user()
        {
            InitializeComponent();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            authorization.testOnClickBut = false;
            this.Hide();
            authorization auto = new authorization();
            auto.Show();
        }

        private void FutureForm_Click(object sender, EventArgs e)
        {
            //this.Hide();
            if (clientsandorders.Checked)
            {

                clientsorder or = new clientsorder();
                    or.Show();
                
            }
            if (employees.Checked)
            {

                    exployees oor = new exployees();
                    oor.Show();
                
            }
            if (flowers.Checked)
            {

                    flowers oor = new flowers();
                    oor.Show();
                
            }
            if (bouqets.Checked)
            {
                boueqts oor = new boueqts();
                oor.Show();

            }
            if (accessories.Checked)
            {
             accessories oor = new accessories();
                    oor.Show();
                
            }
            if (goods_in_the_order.Checked)
            {
      
                    goodsINOrdersView ir = new goodsINOrdersView();
                    ir.Show();
                
            }
            if (goods_on_sale.Checked)
            {
                
                    goodsOnSaleView oor = new goodsOnSaleView();
                    oor.Show();
                
            }
            if (checkBox1.Checked)
            {
                  suplyAndSupliers oor = new suplyAndSupliers();
                    oor.Show();
                
            }
        }



        private void button_add_moneybutton_add_money_Click(object sender, EventArgs e)
        {


                reportFor = 3;
                chooseYear ir = new chooseYear();
                ir.Show();
            }
        

        private void button4_Click(object sender, EventArgs e)
        {
           
                reportFor = 1;
                chooseYear ir = new chooseYear();
                ir.Show();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
                reportFor = 2;
                chooseYear ir = new chooseYear();
                ir.Show();
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
                bonusForClient ir = new bonusForClient();
                ir.Show();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
                suplyForm ir = new suplyForm();
                ir.Show();
            
        }

        private void clientsandorders_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
