﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class accessories : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;

        public accessories()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            try
            {
                if (authorization.testOnClickBut != true)
                {

                    sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Accessories]", sqlconn);

                    sqlbuild = new SqlCommandBuilder(sqldataadapter);
                    sqlbuild.GetInsertCommand();
                    sqlbuild.GetUpdateCommand();
                    sqlbuild.GetDeleteCommand();

                    dataset = new DataSet();
                    sqldataadapter.Fill(dataset, "Accessories");

                    dataGridView1.DataSource = dataset.Tables["Accessories"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[5, i] = linkcell;
                    }

                }
                else
                {
                    sqldataadapter = new SqlDataAdapter("SELECT * FROM [Accessories]", sqlconn);

                    sqlbuild = new SqlCommandBuilder(sqldataadapter);
                    sqlbuild.GetInsertCommand();
                    sqlbuild.GetUpdateCommand();
                    sqlbuild.GetDeleteCommand();

                    dataset = new DataSet();
                    sqldataadapter.Fill(dataset, "Accessories");

                    dataGridView1.DataSource = dataset.Tables["Accessories"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[4, i] = linkcell;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    dataset.Tables["Accessories"].Clear();

                    sqldataadapter.Fill(dataset, "Accessories");

                    dataGridView1.DataSource = dataset.Tables["Accessories"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[5, i] = linkcell;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void accessories_Load(object sender, EventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                panel1.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;

                button1.Visible = false;
                CreateColums();
                RefreshDataGrid(dataGridView1);
            }
            else
            {
                panel1.Visible = false;
                panel3.Visible = false;
                panel4.Visible = false;

                button1.Visible = true;
                string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
                sqlconn = new SqlConnection(connectionString);
                sqlconn.Open();
                LoadData();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

                try
                {
                    if (e.ColumnIndex == 5)
                    {
                        string task = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();

                        if (task == "DELETE")
                        {
                            if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                int rowIndex = e.RowIndex;

                                dataGridView1.Rows.RemoveAt(rowIndex);

                                dataset.Tables["Accessories"].Rows[rowIndex].Delete();

                                sqldataadapter.Update(dataset, "Accessories");
                            }
                        }
                        else if (task == "INSERT")
                        {
                            int rowIndex = dataGridView1.Rows.Count - 2;
                            DataRow row = dataset.Tables["Accessories"].NewRow();

                            row["Name_accessory"] = dataGridView1.Rows[rowIndex].Cells["Name_accessory"].Value;
                            row["Color_accessory"] = dataGridView1.Rows[rowIndex].Cells["Color_accessory"].Value;
                            row["Actual_availability"] = dataGridView1.Rows[rowIndex].Cells["Actual_availability"].Value;
                            row["Price"] = dataGridView1.Rows[rowIndex].Cells["Price"].Value;

                            dataset.Tables["Accessories"].Rows.Add(row);
                            dataset.Tables["Accessories"].Rows.RemoveAt(dataset.Tables["Accessories"].Rows.Count - 1);
                            dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";

                            sqldataadapter.Update(dataset, "Accessories");
                            newRoading = false;
                        }
                        else if (task == "UPDATE")
                        {
                            int r = e.RowIndex;
                            dataset.Tables["Accessories"].Rows[r]["Name_accessory"] = dataGridView1.Rows[r].Cells["Name_accessory"].Value;
                            dataset.Tables["Accessories"].Rows[r]["Color_accessory"] = dataGridView1.Rows[r].Cells["Color_accessory"].Value;
                            dataset.Tables["Accessories"].Rows[r]["Actual_availability"] = dataGridView1.Rows[r].Cells["Actual_availability"].Value;
                            dataset.Tables["Accessories"].Rows[r]["Price"] = dataGridView1.Rows[r].Cells["Price"].Value;

                            sqldataadapter.Update(dataset, "Accessories");
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";

                        }
                        ReloadData();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                
            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    if (newRoading == false)
                    {
                        newRoading = true;
                        int lastRow = dataGridView1.Rows.Count - 2;

                        DataGridViewRow row = dataGridView1.Rows[lastRow];
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[5, lastRow] = linkcell;

                        row.Cells["Command"].Value = "INSERT";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {
                try
                {
                    if (newRoading == false)
                    {
                        int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                        DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[5, rowIndex] = linkcell;

                        editingrow.Cells["Command"].Value = "UPDATE";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //настройки для пользователя
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        private void textBox_id_aces_TextChanged(object sender, EventArgs e)
        {
            textBox_id_aces.ReadOnly = true;

        }

        private void textBox_name_aces_TextChanged(object sender, EventArgs e)
        {
            textBox_name_aces.ReadOnly = true;

        }

        private void textBox_color_TextChanged(object sender, EventArgs e)
        {
            textBox_color.ReadOnly = true;

        }

        private void textBox_numbers_of_TextChanged(object sender, EventArgs e)
        {
            textBox_numbers_of.ReadOnly = true;

        }

        private void textBox_price_TextChanged(object sender, EventArgs e)
        {
            textBox_price.ReadOnly = true;

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ClearFields();
            RefreshDataGrid(dataGridView1);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                int selectedRow = e.RowIndex;
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[selectedRow];
                    textBox_id_aces.Text = row.Cells[0].Value.ToString();
                    textBox_name_aces.Text = row.Cells[1].Value.ToString();
                    textBox_color.Text = row.Cells[2].Value.ToString();
                    textBox_numbers_of.Text = row.Cells[3].Value.ToString();
                    textBox_price.Text = row.Cells[4].Value.ToString();
                }
            }
        }

        private void ClearFields()
        {
            textBox_id_aces.Text = "";
            textBox_name_aces.Text = "";
            textBox_numbers_of.Text = "";
            textBox_price.Text = "";
            textBox_color.Text = "";
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("AccessoryID", "ID");
            dataGridView1.Columns.Add("Name_accessory", "Название аксессуара");
            dataGridView1.Columns.Add("Color_accessory", "Цвет");
            dataGridView1.Columns.Add("Actual_availability", "Актуальное количество");
            dataGridView1.Columns.Add("Price", "Цена");

        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2),
                          record.GetValue(3),
                          record.GetValue(4));


        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = "SELECT * FROM Accessories";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }


        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

            connection.Open();
            SqlCommand com = new SqlCommand(searchString, connection);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();


        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            string searchString = @"SELECT * FROM Accessories WHERE CONCAT(AccessoryID, Name_accessory, Color_accessory, Actual_availability, Price)  LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
