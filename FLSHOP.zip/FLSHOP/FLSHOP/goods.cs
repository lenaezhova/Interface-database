﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class goods : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;

        public goods()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            try
            {
                sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Goods]", sqlconn);

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Goods");

                dataGridView1.DataSource = dataset.Tables["Goods"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[3, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            try
            {
                dataset.Tables["Goods"].Clear();

                sqldataadapter.Fill(dataset, "Goods");

                dataGridView1.DataSource = dataset.Tables["Goods"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[3, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }
        private void goods_Load(object sender, EventArgs e)
        {

            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 3)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

                    if (task == "DELETE")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);

                            dataset.Tables["Goods"].Rows[rowIndex].Delete();

                            sqldataadapter.Update(dataset, "Goods");
                        }
                    }
                    else if (task == "INSERT")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;
                        DataRow row = dataset.Tables["Goods"].NewRow();

                        row["Name_good"] = dataGridView1.Rows[rowIndex].Cells["Name_good"].Value;
                        row["Type_good"] = dataGridView1.Rows[rowIndex].Cells["Type_good"].Value;

                        dataset.Tables["Goods"].Rows.Add(row);
                        dataset.Tables["Goods"].Rows.RemoveAt(dataset.Tables["Goods"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[3].Value = "DELETE";

                        sqldataadapter.Update(dataset, "Goods");
                        newRoading = false;
                    }
                    else if (task == "UPDATE")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Goods"].Rows[r]["Name_good"] = dataGridView1.Rows[r].Cells["Name_good"].Value;
                        dataset.Tables["Goods"].Rows[r]["Type_good"] = dataGridView1.Rows[r].Cells["Type_good"].Value;

                        sqldataadapter.Update(dataset, "Goods");
                        dataGridView1.Rows[e.RowIndex].Cells[3].Value = "DELETE";

                    }
                    ReloadData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    newRoading = true;
                    int lastRow = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRow];
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[3, lastRow] = linkcell;

                    row.Cells["Command"].Value = "INSERT";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[3, rowIndex] = linkcell;

                    editingrow.Cells["Command"].Value = "UPDATE";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void clos_MouseEnter(object sender, EventArgs e)
        {
            clos.ForeColor = Color.White;

        }

        private void clos_MouseLeave(object sender, EventArgs e)
        {
            System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#aae9d6");
            clos.ForeColor = col;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }

}
