﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class bonusForClient : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public bonusForClient()
        {
            InitializeComponent();
        }

        private void button_save_Click(object sender, EventArgs e)
        {

                connection.Open();
                using (connection)
                {
                    SqlCommand command = new SqlCommand("finalCost", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@clientID", SqlDbType.Int));
                    command.Parameters.Add(new SqlParameter("@orderID", SqlDbType.Int));

                    command.Parameters["@clientID"].Value = Convert.ToInt32(textBox_id_client.Text);
                    command.Parameters["@orderID"].Value = Convert.ToInt32(textBox_id_order.Text);
                    command.ExecuteNonQuery();
                    
                }
                connection.Close();
                clientsorder or = new clientsorder();
                or.Show();
            
        }

        private void textBox_surname_client_TextChanged(object sender, EventArgs e)
        {

        }

        private void clos_Click(object sender, EventArgs e)
        {
            this.Hide();

        }
    }
}
