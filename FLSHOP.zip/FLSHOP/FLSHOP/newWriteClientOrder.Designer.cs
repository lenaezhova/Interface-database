﻿namespace FLSHOP
{
    partial class newWriteClientOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button_save = new System.Windows.Forms.Button();
            this.textBox_date_order = new System.Windows.Forms.TextBox();
            this.clos = new System.Windows.Forms.Label();
            this.textBox_surname_client = new System.Windows.Forms.TextBox();
            this.textBox_name_client = new System.Windows.Forms.TextBox();
            this.textBox_phone_number = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.surname_client = new System.Windows.Forms.Label();
            this.Name_client = new System.Windows.Forms.Label();
            this.date_order = new System.Windows.Forms.Label();
            this.phone_number = new System.Windows.Forms.Label();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(449, 313);
            this.panel2.TabIndex = 5;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button_save);
            this.panel1.Controls.Add(this.textBox_date_order);
            this.panel1.Controls.Add(this.clos);
            this.panel1.Controls.Add(this.textBox_surname_client);
            this.panel1.Controls.Add(this.textBox_name_client);
            this.panel1.Controls.Add(this.textBox_phone_number);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.surname_client);
            this.panel1.Controls.Add(this.Name_client);
            this.panel1.Controls.Add(this.date_order);
            this.panel1.Controls.Add(this.phone_number);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 313);
            this.panel1.TabIndex = 18;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(155, 258);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 17;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // textBox_date_order
            // 
            this.textBox_date_order.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_date_order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_date_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_date_order.Location = new System.Drawing.Point(228, 173);
            this.textBox_date_order.Name = "textBox_date_order";
            this.textBox_date_order.Size = new System.Drawing.Size(209, 28);
            this.textBox_date_order.TabIndex = 16;
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(420, -1);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // textBox_surname_client
            // 
            this.textBox_surname_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_surname_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_surname_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_surname_client.Location = new System.Drawing.Point(228, 98);
            this.textBox_surname_client.Name = "textBox_surname_client";
            this.textBox_surname_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_surname_client.TabIndex = 12;
            // 
            // textBox_name_client
            // 
            this.textBox_name_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_name_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name_client.Location = new System.Drawing.Point(228, 123);
            this.textBox_name_client.Name = "textBox_name_client";
            this.textBox_name_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_name_client.TabIndex = 11;
            // 
            // textBox_phone_number
            // 
            this.textBox_phone_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_phone_number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_phone_number.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_phone_number.Location = new System.Drawing.Point(228, 148);
            this.textBox_phone_number.Name = "textBox_phone_number";
            this.textBox_phone_number.Size = new System.Drawing.Size(209, 28);
            this.textBox_phone_number.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Candara", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(150, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(184, 37);
            this.label9.TabIndex = 8;
            this.label9.Text = "Новая запись";
            // 
            // surname_client
            // 
            this.surname_client.AutoSize = true;
            this.surname_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surname_client.Location = new System.Drawing.Point(24, 98);
            this.surname_client.Name = "surname_client";
            this.surname_client.Size = new System.Drawing.Size(136, 21);
            this.surname_client.TabIndex = 6;
            this.surname_client.Text = "Фамилия клиента";
            this.surname_client.Click += new System.EventHandler(this.surname_client_Click);
            // 
            // Name_client
            // 
            this.Name_client.AutoSize = true;
            this.Name_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_client.Location = new System.Drawing.Point(25, 125);
            this.Name_client.Name = "Name_client";
            this.Name_client.Size = new System.Drawing.Size(102, 21);
            this.Name_client.TabIndex = 5;
            this.Name_client.Text = "Имя клиента";
            // 
            // date_order
            // 
            this.date_order.AutoSize = true;
            this.date_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.date_order.Location = new System.Drawing.Point(25, 179);
            this.date_order.Name = "date_order";
            this.date_order.Size = new System.Drawing.Size(94, 21);
            this.date_order.TabIndex = 2;
            this.date_order.Text = "Дата заказа";
            // 
            // phone_number
            // 
            this.phone_number.AutoSize = true;
            this.phone_number.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.phone_number.Location = new System.Drawing.Point(25, 152);
            this.phone_number.Name = "phone_number";
            this.phone_number.Size = new System.Drawing.Size(135, 21);
            this.phone_number.TabIndex = 1;
            this.phone_number.Text = "Номер телефона";
            // 
            // newWriteClientOrder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(449, 313);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "newWriteClientOrder";
            this.Text = "newWriteClientOrder";
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox_surname_client;
        private System.Windows.Forms.TextBox textBox_name_client;
        private System.Windows.Forms.TextBox textBox_phone_number;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label surname_client;
        private System.Windows.Forms.Label Name_client;
        private System.Windows.Forms.Label date_order;
        private System.Windows.Forms.Label phone_number;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.TextBox textBox_date_order;
        private System.Windows.Forms.Button button_save;
    }
}