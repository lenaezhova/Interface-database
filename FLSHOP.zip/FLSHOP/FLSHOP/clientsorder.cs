﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FLSHOP
{
    
    enum RowState 
    {
        Existed, 
        New, 
        Modified, 
        ModifiedNew, 
        Delected
    }

    public partial class clientsorder : Form
    {
        int selectedRow;
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");
        public clientsorder()
        {
            InitializeComponent();
        }
        private void clos_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State != ConnectionState.Closed) connection.Close();
            this.Hide();
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add( "ID_order", "Номер заказа");
            dataGridView1.Columns.Add( "ID_client", "Номер клиента");
            dataGridView1.Columns.Add("Surname", "Фамилия клиента");
            dataGridView1.Columns.Add("Name", "Имя клиента");
            dataGridView1.Columns.Add("Phone_number", "Номер телефона");
            dataGridView1.Columns.Add("Bonus", "Скидка");
            dataGridView1.Columns.Add("Date_order", "Дата заказа");
            dataGridView1.Columns.Add("Cost", "Стоимость");
            dataGridView1.Columns.Add("Surname_of_empl", "Фамилия исполнителя");
            dataGridView1.Columns.Add(String.Empty, "Новая запись");

        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2),
                          record.GetValue(3),
                          record.GetValue(4),
                          record.GetValue(5),
                          record.GetDateTime(6).ToString("yyyy-MM-dd"),
                          record.GetValue(7),
                          record.GetValue(8),
                          RowState.ModifiedNew);

        }
        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = $"SELECT * FROM ClientDataOrderEmployee";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }

        private void clientsorder_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridView1);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];
                textBox_id_order.Text = row.Cells[0].Value.ToString();
                textBox_id_client.Text = row.Cells[1].Value.ToString();
                textBox_surname_client.Text = row.Cells[2].Value.ToString();
                textBox_name_client.Text = row.Cells[3].Value.ToString();
                textBox_phone_number.Text = row.Cells[4].Value.ToString();
                textBox_bonus.Text = row.Cells[5].Value.ToString();
                textBox_date_order.Text = row.Cells[6].Value.ToString();
                textBox_cost.Text = row.Cells[7].Value.ToString();
                textBox_surname_of_empl.Text = row.Cells[8].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
            ClearFields();

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {
            newWriteClientOrder add = new newWriteClientOrder();
            add.Show();
        }

        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

                connection.Open();
                SqlCommand com = new SqlCommand(searchString, connection);
                SqlDataReader reader = com.ExecuteReader();
                while (reader.Read())
                {
                    ReadSingleRow(dgv, reader);
                }
                reader.Close();
                connection.Close();


        }
        private void search_TextChanged(object sender, EventArgs e)
        {
            //for(int i = 0; i < search.Text.Length; i++)
            //{
            //    if (search.Text[i] == '.')
            //    {
            //        if (i == 2)
            //        {
            //            string tmp = "-" + search.Text[0] + search.Text[1];
            //            search.Text = tmp;
            //        }
            //        else if (i = 2)
            //    }
                
            //}

            string searchString = @"SELECT * FROM ClientDataOrderEmployee WHERE CONCAT(ID_order, ID_client, Surname, Name, Phone_number, Bonus,  CONVERT(VARCHAR(25), Date_order), Cost, Surname_of_empl) LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }


        private void Updatee()
        {
            connection.Open();  
            for (int index = 0; index < dataGridView1.Rows.Count; index++)
            {
                RowState rowState = (RowState)Convert.ToInt32(dataGridView1.Rows[index].Cells[9].Value);

                if (rowState == RowState.ModifiedNew) continue;
                
                if (rowState == RowState.Modified)
                {
                    //var id = dataGridView1.Rows[index].Cells[0].Value.ToString();
                    var ID = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);

                    var sur = dataGridView1.Rows[index].Cells[2].Value.ToString();
                    var name = dataGridView1.Rows[index].Cells[3].Value.ToString();
                    var ph = dataGridView1.Rows[index].Cells[4].Value.ToString();
                    //var bonus = dataGridView1.Rows[index].Cells[4].Value.ToString();
                    var date = dataGridView1.Rows[index].Cells[6].Value.ToString();
                    //var cost = dataGridView1.Rows[index].Cells[6].Value.ToString();
                    var em = dataGridView1.Rows[index].Cells[8].Value.ToString();

                    var changeQuery = $"UPDATE ClientDataOrderEmployee SET Surname_of_empl = '{em}', Name = '{name}', Phone_number = '{ph}', Date_order = '{date}' WHERE ID_order = {ID}";

                    var command = new SqlCommand(changeQuery, connection);
                    command.ExecuteNonQuery();
                }

            }
            connection.Close();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            Updatee();
            ClearFields();
        }
        private void change()
        {
            var salectedRowIndex = dataGridView1.CurrentCell.RowIndex;

            var surname = textBox_surname_client.Text;
            var name = textBox_name_client.Text;
            var phone_number = textBox_phone_number.Text;
            var date_order = textBox_date_order.Text;

            var bonus = textBox_bonus.Text;
            var id_order = textBox_id_order.Text;
            var cost = textBox_cost.Text;
            var sur = textBox_surname_of_empl.Text;
            var id_client = textBox_id_client.Text;

            if (dataGridView1.Rows[salectedRowIndex].Cells[0].Value.ToString() != String.Empty)
            {

                    dataGridView1.Rows[salectedRowIndex].SetValues(id_order, id_client, surname, name, phone_number, bonus, date_order, cost, sur);
                    dataGridView1.Rows[salectedRowIndex].Cells[9].Value = RowState.Modified;
            }
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            change();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void ClearFields()
        {
            textBox_id_order.Text = "";
            textBox_bonus.Text = "";
            textBox_cost.Text = "";
            textBox_name_client.Text = "";
            textBox_surname_client.Text = "";
            textBox_surname_of_empl.Text = "";
            textBox_phone_number.Text = "";
            textBox_date_order.Text = "";
            textBox_id_client.Text = "";
        }
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox_id_order_TextChanged(object sender, EventArgs e)
        {
            textBox_id_order.ReadOnly = true;
        }

        private void textBox_bonus_TextChanged(object sender, EventArgs e)
        {
            textBox_bonus.ReadOnly = true;

        }

        private void textBox_cost_TextChanged(object sender, EventArgs e)
        {
            textBox_cost.ReadOnly = true;

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox_id_client_TextChanged(object sender, EventArgs e)
        {
            textBox_id_client.ReadOnly = true;

        }
    }
}



//dataGridView1.Columns.Add("ID_order", "ID_order");
//dataGridView1.Columns.Add("Surname", "Surname");
//dataGridView1.Columns.Add("Name", "Name");
//dataGridView1.Columns.Add("Phone_number", "Phone_number");
//dataGridView1.Columns.Add("Bonus", "Bonus");
//dataGridView1.Columns.Add("Date_order", "Date_order");
//dataGridView1.Columns.Add("Cost", "Cost");
//dataGridView1.Columns.Add("Surname_of_empl", "Surname_of_empl");

//string sqlExpression = "SELECT * FROM ClientDataOrderEmployee";
//using (connection)
//{
//    connection.Open();
//    SqlCommand command = new SqlCommand(sqlExpression, connection);
//    SqlDataReader reader = command.ExecuteReader();

//    if (reader.HasRows) // если есть данные
//    {

//        int counter = 0;
//        while (reader.Read()) // построчно считываем данные
//        {
//            dataGridView1.ReadOnly = true;
//            object ID_order = reader.GetValue(0);
//            object Surname = reader.GetValue(1);
//            object Name = reader.GetValue(2);
//            object Phone_number = reader.GetValue(3);
//            object Bonus = reader.GetValue(4);
//            object Date_order = reader.GetValue(5);
//            object Cost = reader.GetValue(6);
//            object Surname_of_empl = reader.GetValue(7);

//            dataGridView1.Rows.Add();
//            dataGridView1.Rows[counter].Cells[0].Value = ID_order;
//            dataGridView1.Rows[counter].Cells[1].Value = Surname;
//            dataGridView1.Rows[counter].Cells[2].Value = Name;
//            dataGridView1.Rows[counter].Cells[3].Value = Phone_number;
//            dataGridView1.Rows[counter].Cells[4].Value = Bonus;
//            dataGridView1.Rows[counter].Cells[5].Value = Date_order;
//            dataGridView1.Rows[counter].Cells[6].Value = Cost;
//            dataGridView1.Rows[counter].Cells[7].Value = Surname_of_empl;

//            counter++;
//        }
//    }

//    reader.Close();
//}

//Console.Read();