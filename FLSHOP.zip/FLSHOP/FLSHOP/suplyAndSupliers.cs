﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class suplyAndSupliers : Form
    {
        public suplyAndSupliers()
        {
            InitializeComponent();
        }

        private void suplyAndSupliers_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "flower_shopDataSet4.SuppliersAndPriceDays". При необходимости она может быть перемещена или удалена.
            this.suppliersAndPriceDaysTableAdapter.Fill(this.flower_shopDataSet4.SuppliersAndPriceDays);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "flower_shopDataSet4.Supply". При необходимости она может быть перемещена или удалена.
            this.supplyTableAdapter.Fill(this.flower_shopDataSet4.Supply);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "flower_shopDataSet4.Suppliers". При необходимости она может быть перемещена или удалена.
            this.suppliersTableAdapter.Fill(this.flower_shopDataSet4.Suppliers);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "flower_shopDataSet3.Goods". При необходимости она может быть перемещена или удалена.
           
        }

        private void clos_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void clos_Click_1(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
