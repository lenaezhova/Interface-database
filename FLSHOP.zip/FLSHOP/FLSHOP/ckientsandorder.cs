﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    //Database database = new Database();
    //enum rowState
    //{
    //    Exited, 
    //    New,
    //    Modified,
    //    ModifiedNew,
    //    Delected
    //};
    public partial class ckientsandorder : Form
    {
        private SqlConnection sqlconn = null;

        private void LoadData()
        {
            //if (dataGridView2.Rows.Count > 0)
            //{
            //    dataGridView2.Rows.Clear();
            //    dataGridView2.Refresh();
            //}

            //if (dataGridView2.Columns.Count < 1)
            //{
                dataGridView2.Columns.Add("ID_order", "ID_order");
                dataGridView2.Columns.Add("Surname", "Surname");
                dataGridView2.Columns.Add("Name", "Name");
                dataGridView2.Columns.Add("Phone_number", "Phone_number");
                dataGridView2.Columns.Add("Bonus", "Bonus");
                dataGridView2.Columns.Add("Date_order", "Date_order");
                dataGridView2.Columns.Add("Cost", "Cost");
                dataGridView2.Columns.Add("Surname_of_empl", "Surname_of_empl");
            //}

            //string connectionString = @"Data Source = .\SQL_EXPRESS;Initial Catalog=finSql; Integrated Security = True";

            string sqlExpression = "SELECT * FROM ClientDataOrderEmployee";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //{
            //    connection.Open();
            SqlCommand command = new SqlCommand(sqlExpression, sqlconn);
                SqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows) // если есть данные
                {

                    int counter = 0;
                    while (reader.Read()) // построчно считываем данные
                    {
                        dataGridView1.ReadOnly = true;
                        object ID_order = reader.GetValue(0);
                        object Surname = reader.GetValue(1);
                        object Name = reader.GetValue(2);
                        object Phone_number = reader.GetValue(3);
                        object Bonus = reader.GetValue(4);
                        object Date_order = reader.GetValue(5); 
                    object Cost = reader.GetValue(6);
                    object Surname_of_empl = reader.GetValue(7);

                    dataGridView1.Rows.Add();
                        dataGridView1.Rows[counter].Cells[0].Value = ID_order;
                        dataGridView1.Rows[counter].Cells[1].Value = Surname;
                        dataGridView1.Rows[counter].Cells[2].Value = Name;
                        dataGridView1.Rows[counter].Cells[3].Value = Phone_number;
                        dataGridView1.Rows[counter].Cells[4].Value = Bonus;
                        dataGridView1.Rows[counter].Cells[5].Value = Date_order;
                        dataGridView1.Rows[counter].Cells[6].Value = Cost;
                    dataGridView1.Rows[counter].Cells[7].Value = Surname_of_empl;



                    counter++;
                    }
                

                reader.Close();
            }

            Console.Read();

        }
        //    //int selectedRow;

        //    //private SqlCommandBuilder sqlbuild = null;
        //    private SqlDataAdapter sqldataadapter = null;
        //    private DataSet dataset = null;

        //    private bool newRoading = false;

        //    private void LoadData()
        //    {
        //        try
        //        {
        //            sqldataadapter = new SqlDataAdapter("SELECT * FROM [ClientDataOrderEmployee]", sqlconn);

        //            //sqlbuild = new SqlCommandBuilder(sqldataadapter);
        //            //sqlbuild.GetInsertCommand();
        //            //sqlbuild.GetUpdateCommand();
        //            //sqlbuild.GetDeleteCommand();

        //            dataset = new DataSet();
        //            sqldataadapter.Fill(dataset, "ClientDataOrderEmployee");

        //            dataGridView1.DataSource = dataset.Tables["ClientDataOrderEmployee"];

        //            for (int i = 0; i < dataGridView1.Rows.Count; i++)
        //            {
        //                DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
        //                dataGridView1[7, i] = linkcell;
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //        }
        //    }

        //    private void ReloadData()
        //    {
        //        try
        //        {
        //            dataset.Tables["ClientDataOrderEmployee"].Clear();

        //            sqldataadapter.Fill(dataset, "ClientDataOrderEmployee");

        //            dataGridView1.DataSource = dataset.Tables["ClientDataOrderEmployee"];

        //            for (int i = 0; i < dataGridView1.Rows.Count; i++)
        //            {
        //                DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
        //                dataGridView1[8, i] = linkcell;
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //        }
        //    }
        //    public ckientsandorder()
        //    {
        //        InitializeComponent();
        //    }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        //    private void button5_Click(object sender, EventArgs e)
        //    {


        //    }

        private void label3_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }


        private void ckientsandorder_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop__; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();
        }

        //    private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        //    {

        //        try
        //        {
        //            if (e.ColumnIndex == 8)
        //            {
        //                string task = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();

        //                if (task == "INSERT")
        //                {
        //                    int rowIndex = dataGridView1.Rows.Count - 2;
        //                    DataRow row = dataset.Tables["ClientDataOrderEmployee"].NewRow();

        //                    row["ID_order"] = dataGridView1.Rows[rowIndex].Cells["ID_order"].Value;
        //                    row["Surname"] = dataGridView1.Rows[rowIndex].Cells["Surname"].Value;
        //                    row["Name"] = dataGridView1.Rows[rowIndex].Cells["Name"].Value;
        //                    row["Phone_number"] = dataGridView1.Rows[rowIndex].Cells["Phone_number"].Value;
        //                    row["Bonus"] = dataGridView1.Rows[rowIndex].Cells["Bonus"].Value;
        //                    row["Date_order"] = dataGridView1.Rows[rowIndex].Cells["Date_order"].Value;
        //                    row["Cost"] = dataGridView1.Rows[rowIndex].Cells["Cost"].Value;
        //                    row["Surname_of_empl"] = dataGridView1.Rows[rowIndex].Cells["Surname_of_empl"].Value;

        //                    dataset.Tables["Supply"].Rows.Add(row);
        //                    dataset.Tables["Supply"].Rows.RemoveAt(dataset.Tables["Supply"].Rows.Count - 1);
        //                    dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
        //                    dataGridView1.Rows[e.RowIndex].Cells[8].Value = "DELETE";

        //                    sqldataadapter.Update(dataset, "ClientDataOrderEmployee");
        //                    newRoading = false;
        //                }
        //                else if (task == "UPDATE")
        //                {
        //                    int r = e.RowIndex;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["ID_order"] = dataGridView1.Rows[r].Cells["ID_order"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Surname"] = dataGridView1.Rows[r].Cells["Surname"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Name"] = dataGridView1.Rows[r].Cells["Name"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Phone_number"] = dataGridView1.Rows[r].Cells["Phone_number"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Bonus"] = dataGridView1.Rows[r].Cells["Bonus"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Date_order"] = dataGridView1.Rows[r].Cells["Date_order"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Cost"] = dataGridView1.Rows[r].Cells["Cost"].Value;
        //                    dataset.Tables["ClientDataOrderEmployee"].Rows[r]["Surname_of_empl"] = dataGridView1.Rows[r].Cells["Surname_of_empl"].Value;

        //                    sqldataadapter.Update(dataset, "ClientDataOrderEmployee");
        //                    dataGridView1.Rows[e.RowIndex].Cells[8].Value = "DELETE";

        //                }
        //                ReloadData();
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //        }
        //    }

        //    private void dataGridView2_UserAddedRow_1(object sender, DataGridViewRowEventArgs e)
        //    {
        //        try
        //        {
        //            if (newRoading == false)
        //            {
        //                newRoading = true;
        //                int lastRow = dataGridView1.Rows.Count - 2;

        //                DataGridViewRow row = dataGridView1.Rows[lastRow];
        //                DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

        //                dataGridView1[8, lastRow] = linkcell;

        //                row.Cells["Command"].Value = "INSERT";
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //        }
        //    }

        //    private void dataGridView2_CellValueChanged_1(object sender, DataGridViewCellEventArgs e)
        //    {
        //        try
        //        {
        //            if (newRoading == false)
        //            {
        //                int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

        //                DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

        //                DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

        //                dataGridView1[8, rowIndex] = linkcell;

        //                editingrow.Cells["Command"].Value = "UPDATE";
        //            }

        //        }
        //        catch (Exception ex)
        //        {
        //            MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        //        }
        //    }
    }
}



//private void CreateColums()
//{
//    dataGridView2.Columns.Add("ID_order", "ID_order");
//    dataGridView2.Columns.Add("Surname", "Surname");
//    dataGridView2.Columns.Add("Name", "Name");
//    dataGridView2.Columns.Add("Phone_number", "Phone_number");
//    dataGridView2.Columns.Add("Bonus", "Bonus");
//    dataGridView2.Columns.Add("Date_order", "Date_order");
//    dataGridView2.Columns.Add("Cost", "Cost");
//    dataGridView2.Columns.Add("Surname_of_empl", "Surname_of_empl");
//}

//private void ReadSingleRow(DataGridView dgw, IDataRecord record)
//{
//    dgw.Rows.Add(record.GetInt32(0),
//                 record.GetString(1),
//                 record.GetString(2),
//                 record.GetString(3),
//                 record.GetInt32(4),
//                 record.GetData(5),
//                 record.GetInt32(6),
//                 record.GetString(7),
//                 rowState.ModifiedNew);

//}

//private void RefreshDataGrid(DataGridView dgw)
//{
//    dgw.Rows.Clear();
//    string queryString = @"SELECT * FROM ClientDataOrderEmployee";
//    string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop__; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
//    sqlconn = new SqlConnection(connectionString);
//    SqlCommand command = new SqlCommand(queryString, sqlconn);
//    sqlconn.Open();

//    SqlDataReader reader = command.ExecuteReader();
//    while (reader.Read())
//    {
//        ReadSingleRow(dgw, reader);
//    }
//    reader.Close();

//}