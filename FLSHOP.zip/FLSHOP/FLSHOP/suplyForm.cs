﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class suplyForm : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public suplyForm()
        {
            InitializeComponent();
        }

        private void surname_client_Click(object sender, EventArgs e)
        {

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            connection.Open();
            using (connection)
            {
                SqlCommand command = new SqlCommand("supplyDay", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(new SqlParameter("@dateOrder", SqlDbType.Date));
                command.Parameters.Add(new SqlParameter("@IDgoodForOr", SqlDbType.Int));
                command.Parameters.Add(new SqlParameter("@num", SqlDbType.Int));
                command.Parameters.Add(new SqlParameter("@ordor", SqlDbType.BigInt));

                command.Parameters["@dateOrder"].Value = textBox_date.Text;
                command.Parameters["@IDgoodForOr"].Value = Convert.ToInt32(textBox_id_good.Text);
                command.Parameters["@num"].Value = Convert.ToInt32(textBox_num.Text);
                if (textBox_order.Text != "null")
                {
                    command.Parameters["@ordor"].Value = Convert.ToInt32(textBox_order.Text);
                }
                else
                {
                    command.Parameters["@ordor"].Value = DBNull.Value;
                }
                command.ExecuteNonQuery();

            }
            connection.Close();
            suplyAndSupliers or = new suplyAndSupliers();
            or.Show();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
