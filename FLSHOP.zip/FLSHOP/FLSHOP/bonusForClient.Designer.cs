﻿namespace FLSHOP
{
    partial class bonusForClient
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_id_client = new System.Windows.Forms.TextBox();
            this.button_save = new System.Windows.Forms.Button();
            this.clos = new System.Windows.Forms.Label();
            this.textBox_id_order = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.textBox_id_client);
            this.panel1.Controls.Add(this.button_save);
            this.panel1.Controls.Add(this.clos);
            this.panel1.Controls.Add(this.textBox_id_order);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(448, 309);
            this.panel1.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(27, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 21);
            this.label2.TabIndex = 20;
            this.label2.Text = "ID заказа";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(27, 116);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 21);
            this.label1.TabIndex = 19;
            this.label1.Text = "ID клиента";
            // 
            // textBox_id_client
            // 
            this.textBox_id_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_id_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_id_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_id_client.Location = new System.Drawing.Point(214, 114);
            this.textBox_id_client.Name = "textBox_id_client";
            this.textBox_id_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_id_client.TabIndex = 18;
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(155, 238);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 17;
            this.button_save.Text = "Рассчитать";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(420, -1);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // textBox_id_order
            // 
            this.textBox_id_order.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_id_order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_id_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_id_order.Location = new System.Drawing.Point(214, 141);
            this.textBox_id_order.Name = "textBox_id_order";
            this.textBox_id_order.Size = new System.Drawing.Size(209, 28);
            this.textBox_id_order.TabIndex = 12;
            this.textBox_id_order.TextChanged += new System.EventHandler(this.textBox_surname_client_TextChanged);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Candara", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(48, -14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(366, 63);
            this.label9.TabIndex = 8;
            this.label9.Text = "Введите данные:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // bonusForClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 309);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "bonusForClient";
            this.Text = "bonusForClient";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.TextBox textBox_id_order;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_id_client;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}