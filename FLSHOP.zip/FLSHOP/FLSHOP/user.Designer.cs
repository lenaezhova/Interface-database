﻿namespace FLSHOP
{
    partial class user
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_add_moneybutton_add_money = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.employees = new System.Windows.Forms.CheckBox();
            this.clientsandorders = new System.Windows.Forms.CheckBox();
            this.goods_on_sale = new System.Windows.Forms.CheckBox();
            this.goods_in_the_order = new System.Windows.Forms.CheckBox();
            this.accessories = new System.Windows.Forms.CheckBox();
            this.bouqets = new System.Windows.Forms.CheckBox();
            this.flowers = new System.Windows.Forms.CheckBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.clos = new System.Windows.Forms.Label();
            this.chose = new System.Windows.Forms.Label();
            this.close = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.FutureForm = new System.Windows.Forms.Button();
            this.returnBack = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.FutureForm);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.button_add_moneybutton_add_money);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.employees);
            this.panel1.Controls.Add(this.clientsandorders);
            this.panel1.Controls.Add(this.goods_on_sale);
            this.panel1.Controls.Add(this.goods_in_the_order);
            this.panel1.Controls.Add(this.accessories);
            this.panel1.Controls.Add(this.bouqets);
            this.panel1.Controls.Add(this.flowers);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.close);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(638, 649);
            this.panel1.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Candara Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.Location = new System.Drawing.Point(77, 447);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(151, 33);
            this.button4.TabIndex = 36;
            this.button4.Text = "Выручка за год";
            this.button4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Candara Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.Location = new System.Drawing.Point(77, 499);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(151, 33);
            this.button3.TabIndex = 35;
            this.button3.Text = "Затраты за год";
            this.button3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Candara Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.Location = new System.Drawing.Point(389, 396);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(179, 33);
            this.button2.TabIndex = 34;
            this.button2.Text = " Применить скидку";
            this.button2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Candara Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.Location = new System.Drawing.Point(389, 447);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(179, 33);
            this.button1.TabIndex = 33;
            this.button1.Text = "Заказ товара \r\n";
            this.button1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_add_moneybutton_add_money
            // 
            this.button_add_moneybutton_add_money.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_add_moneybutton_add_money.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_add_moneybutton_add_money.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_add_moneybutton_add_money.Font = new System.Drawing.Font("Candara Light", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_add_moneybutton_add_money.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_add_moneybutton_add_money.Location = new System.Drawing.Point(77, 396);
            this.button_add_moneybutton_add_money.Name = "button_add_moneybutton_add_money";
            this.button_add_moneybutton_add_money.Size = new System.Drawing.Size(151, 33);
            this.button_add_moneybutton_add_money.TabIndex = 32;
            this.button_add_moneybutton_add_money.Text = "Прибыль за год";
            this.button_add_moneybutton_add_money.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button_add_moneybutton_add_money.UseVisualStyleBackColor = false;
            this.button_add_moneybutton_add_money.Click += new System.EventHandler(this.button_add_moneybutton_add_money_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(3, 304);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(638, 57);
            this.panel4.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara Light", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.label1.Location = new System.Drawing.Point(209, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(209, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Выберите действие";
            // 
            // checkBox1
            // 
            this.checkBox1.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.checkBox1.Location = new System.Drawing.Point(389, 201);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(254, 27);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "Доставки и поставщики";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // employees
            // 
            this.employees.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.employees.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.employees.Location = new System.Drawing.Point(389, 168);
            this.employees.Name = "employees";
            this.employees.Size = new System.Drawing.Size(254, 27);
            this.employees.TabIndex = 24;
            this.employees.Text = "Сотрудники";
            this.employees.UseVisualStyleBackColor = true;
            // 
            // clientsandorders
            // 
            this.clientsandorders.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clientsandorders.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clientsandorders.Location = new System.Drawing.Point(77, 102);
            this.clientsandorders.Name = "clientsandorders";
            this.clientsandorders.Size = new System.Drawing.Size(254, 27);
            this.clientsandorders.TabIndex = 23;
            this.clientsandorders.Text = "Клиенты и их заказы";
            this.clientsandorders.UseVisualStyleBackColor = true;
            this.clientsandorders.CheckedChanged += new System.EventHandler(this.clientsandorders_CheckedChanged);
            // 
            // goods_on_sale
            // 
            this.goods_on_sale.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.goods_on_sale.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.goods_on_sale.Location = new System.Drawing.Point(389, 135);
            this.goods_on_sale.Name = "goods_on_sale";
            this.goods_on_sale.Size = new System.Drawing.Size(214, 27);
            this.goods_on_sale.TabIndex = 22;
            this.goods_on_sale.Text = "Товары в продаже";
            this.goods_on_sale.UseVisualStyleBackColor = true;
            // 
            // goods_in_the_order
            // 
            this.goods_in_the_order.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.goods_in_the_order.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.goods_in_the_order.Location = new System.Drawing.Point(77, 135);
            this.goods_in_the_order.Name = "goods_in_the_order";
            this.goods_in_the_order.Size = new System.Drawing.Size(214, 27);
            this.goods_in_the_order.TabIndex = 19;
            this.goods_in_the_order.Text = "Товары в заказе";
            this.goods_in_the_order.UseVisualStyleBackColor = true;
            // 
            // accessories
            // 
            this.accessories.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.accessories.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.accessories.Location = new System.Drawing.Point(389, 102);
            this.accessories.Name = "accessories";
            this.accessories.Size = new System.Drawing.Size(214, 27);
            this.accessories.TabIndex = 14;
            this.accessories.Text = "Аксессуары";
            this.accessories.UseVisualStyleBackColor = true;
            // 
            // bouqets
            // 
            this.bouqets.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bouqets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.bouqets.Location = new System.Drawing.Point(77, 201);
            this.bouqets.Name = "bouqets";
            this.bouqets.Size = new System.Drawing.Size(214, 27);
            this.bouqets.TabIndex = 13;
            this.bouqets.Text = "Букеты";
            this.bouqets.UseVisualStyleBackColor = true;
            // 
            // flowers
            // 
            this.flowers.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.flowers.Location = new System.Drawing.Point(77, 168);
            this.flowers.Name = "flowers";
            this.flowers.Size = new System.Drawing.Size(214, 27);
            this.flowers.TabIndex = 12;
            this.flowers.Text = "Цветы";
            this.flowers.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.clos);
            this.panel3.Controls.Add(this.chose);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(636, 87);
            this.panel3.TabIndex = 9;
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(606, 0);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 10;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // chose
            // 
            this.chose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chose.Font = new System.Drawing.Font("Candara Light", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.chose.Location = new System.Drawing.Point(0, 0);
            this.chose.Name = "chose";
            this.chose.Size = new System.Drawing.Size(636, 87);
            this.chose.TabIndex = 8;
            this.chose.Text = "Выберите таблицу для просмотра";
            this.chose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.close.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.close.Location = new System.Drawing.Point(406, -1);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(29, 35);
            this.close.TabIndex = 6;
            this.close.Text = "x";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.returnBack);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 559);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(636, 88);
            this.panel2.TabIndex = 5;
            // 
            // FutureForm
            // 
            this.FutureForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.FutureForm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.FutureForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FutureForm.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FutureForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.FutureForm.Location = new System.Drawing.Point(429, 250);
            this.FutureForm.Name = "FutureForm";
            this.FutureForm.Size = new System.Drawing.Size(174, 35);
            this.FutureForm.TabIndex = 11;
            this.FutureForm.Text = "Далее";
            this.FutureForm.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.FutureForm.UseVisualStyleBackColor = false;
            this.FutureForm.Click += new System.EventHandler(this.FutureForm_Click);
            // 
            // returnBack
            // 
            this.returnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.returnBack.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.returnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.returnBack.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.returnBack.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.returnBack.Location = new System.Drawing.Point(11, 31);
            this.returnBack.Name = "returnBack";
            this.returnBack.Size = new System.Drawing.Size(174, 35);
            this.returnBack.TabIndex = 4;
            this.returnBack.Text = "Вернуться назад";
            this.returnBack.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.returnBack.UseVisualStyleBackColor = false;
            this.returnBack.Click += new System.EventHandler(this.returnBack_Click);
            // 
            // user
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(638, 649);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "user";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "user";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox goods_in_the_order;
        private System.Windows.Forms.CheckBox accessories;
        private System.Windows.Forms.CheckBox bouqets;
        private System.Windows.Forms.CheckBox flowers;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.Label chose;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button FutureForm;
        private System.Windows.Forms.Button returnBack;
        private System.Windows.Forms.CheckBox goods_on_sale;
        private System.Windows.Forms.CheckBox clientsandorders;
        private System.Windows.Forms.CheckBox employees;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_add_moneybutton_add_money;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
    }
}