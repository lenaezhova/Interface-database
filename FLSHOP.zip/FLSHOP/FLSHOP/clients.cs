﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FLSHOP
{
    
    public partial class clients : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;

        public clients()
        {
            InitializeComponent();
        }
        
        private void LoadData()
        {
            try {


                    sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Clients]", sqlconn);

            

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Clients");

                dataGridView1.DataSource = dataset.Tables["Clients"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[5, i]  = linkcell;
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            try
            {
                dataset.Tables["Clients"].Clear();

                sqldataadapter.Fill(dataset, "Clients");

                dataGridView1.DataSource = dataset.Tables["Clients"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[5, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void clients_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "flower_shop__DataSet.Clients". При необходимости она может быть перемещена или удалена.
            this.clientsTableAdapter.Fill(this.flower_shop__DataSet.Clients);

            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();

        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();

        }


        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 5)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();


                    if (task == "DELETE")
                    {
                       
                            if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                int rowIndex = e.RowIndex;

                                dataGridView1.Rows.RemoveAt(rowIndex);

                                dataset.Tables["Clients"].Rows[rowIndex].Delete();

                                sqldataadapter.Update(dataset, "Clients");
                            }
                        
                    }
                    else if (task == "INSERT" )
                        {
                            int rowIndex = dataGridView1.Rows.Count - 2;
                            DataRow row = dataset.Tables["Clients"].NewRow();

                            row["Surname"] = dataGridView1.Rows[rowIndex].Cells["Surname"].Value;
                            row["Name"] = dataGridView1.Rows[rowIndex].Cells["Name"].Value;
                            row["Phone_number"] = dataGridView1.Rows[rowIndex].Cells["Phone_number"].Value;
                            row["Bonus"] = dataGridView1.Rows[rowIndex].Cells["Bonus"].Value;

                            dataset.Tables["Clients"].Rows.Add(row);
                            dataset.Tables["Clients"].Rows.RemoveAt(dataset.Tables["Clients"].Rows.Count - 1);
                            dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);


                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";
                            sqldataadapter.Update(dataset, "Clients");
                            newRoading = false;
                        
                    }
                    else if (task == "UPDATE")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Clients"].Rows[r]["Surname"] = dataGridView1.Rows[r].Cells["Surname"].Value;
                        dataset.Tables["Clients"].Rows[r]["Name"] = dataGridView1.Rows[r].Cells["Name"].Value;
                        dataset.Tables["Clients"].Rows[r]["Phone_number"] = dataGridView1.Rows[r].Cells["Phone_number"].Value;
                        dataset.Tables["Clients"].Rows[r]["Bonus"] = dataGridView1.Rows[r].Cells["Bonus"].Value;

                        sqldataadapter.Update(dataset, "Clients");
                        if (authorization.testOnClickBut != true)
                        {
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "DELETE";
                        }
                        else
                        {
                            dataGridView1.Rows[e.RowIndex].Cells[5].Value = "";
                        }

                    }
                        ReloadData();
                    }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {

                try
                {
                    if (newRoading == false)
                    {
                        newRoading = true;
                        int lastRow = dataGridView1.Rows.Count - 2;

                        DataGridViewRow row = dataGridView1.Rows[lastRow];
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[5, lastRow] = linkcell;

                        row.Cells["Command"].Value = "INSERT";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[5, rowIndex] = linkcell;

                    editingrow.Cells["Command"].Value = "UPDATE";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }


        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void clos_MouseEnter(object sender, EventArgs e)
        {
            clos.ForeColor = Color.White;

        }

        private void clos_MouseLeave(object sender, EventArgs e)
        {
            System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#aae9d6");
            clos.ForeColor = col;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}


//Data Source = ELENA; Initial Catalog = Flower_shop__; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False