﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class goodsINOrdersView : Form
    {
        int selectedRow;
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public goodsINOrdersView()
        {
            InitializeComponent();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State != ConnectionState.Closed) connection.Close();
            this.Hide();
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("ID_order", "Номер заказа");
            dataGridView1.Columns.Add("Name_good", "Название товара");
            dataGridView1.Columns.Add("Type_of", "Тип товара");
            dataGridView1.Columns.Add("Number_of_goods", "Количество");
            dataGridView1.Columns.Add(String.Empty, "Новая запись");

        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2),
                          record.GetValue(3),
                          RowState.ModifiedNew);

        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = "SELECT * FROM goodsInTheOrder";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }

        private void goodsINOrdersView_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridView1);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];
                textBox_id_order.Text = row.Cells[0].Value.ToString();
                textBox_name_good.Text = row.Cells[1].Value.ToString();
                textBox_type_of.Text = row.Cells[2].Value.ToString();
                textBox_numbers_of.Text = row.Cells[3].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
            ClearFields();

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {

            numberfOrder add = new numberfOrder();
            add.Show();
        }

        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

            connection.Open();
            SqlCommand com = new SqlCommand(searchString, connection);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();


        }
        private void search_TextChanged(object sender, EventArgs e)
        {
            string searchString = @"SELECT * FROM goodsInTheOrder WHERE CONCAT(ID_order, Name_good, Type_of, Number_of_goods)  LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }

        private void deleteRow()
        {
            int index = dataGridView1.CurrentCell.RowIndex;
            dataGridView1.Rows[index].Visible = false;
            if (dataGridView1.Rows[index].Cells[0].Value.ToString() != string.Empty)
            {
                dataGridView1.Rows[index].Cells[4].Value = RowState.Delected;
            }
        }

        private void Updatee()
        {
            connection.Open();
            for (int index = 0; index < dataGridView1.Rows.Count; index++)
            {
                RowState rowState = new RowState();

               rowState = (RowState)Convert.ToInt32(dataGridView1.Rows[index].Cells[4].Value);

                if (rowState == RowState.ModifiedNew) continue;

                if (rowState == RowState.Delected)
                {
                    var ID = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);
                    var name = dataGridView1.Rows[index].Cells[1].Value.ToString();
                    var daletQuery = $"DELETE FROM goodsInTheOrder WHERE ID_order = {ID} AND Name_good = '{name}'";
                    var command = new SqlCommand(daletQuery, connection);
                    command.ExecuteNonQuery();

                }
                if (rowState == RowState.Modified)
                {
                    var ID = Convert.ToInt32(dataGridView1.Rows[index].Cells[0].Value);

                    var name = dataGridView1.Rows[index].Cells[1].Value.ToString();
                    var type = dataGridView1.Rows[index].Cells[2].Value.ToString();
                    var num = dataGridView1.Rows[index].Cells[3].Value.ToString();

                    var changeQuery = $"UPDATE goodsInTheOrder SET Number_of_goods = '{num}' WHERE  ID_order = {ID} AND Name_good = '{name}'";

                    var command = new SqlCommand(changeQuery, connection);
                    command.ExecuteNonQuery();
                }

            }
            connection.Close();
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            deleteRow();
            ClearFields();

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            Updatee();
            ClearFields();
        }

        private void change()
        {
            var salectedRowIndex = dataGridView1.CurrentCell.RowIndex;

            var ID = textBox_id_order.Text; 
            var name = textBox_name_good.Text;  
            var type = textBox_type_of.Text;
            var num = textBox_numbers_of.Text;

            if (dataGridView1.Rows[salectedRowIndex].Cells[0].Value.ToString() != String.Empty)
            {
                    dataGridView1.Rows[salectedRowIndex].SetValues(ID, name, type, num);
                    dataGridView1.Rows[salectedRowIndex].Cells[4].Value = RowState.Modified;
            }
        }

        private void ClearFields()
        {
            textBox_id_order.Text = "";
            textBox_name_good.Text = "";
            textBox_numbers_of.Text = "";
            textBox_type_of.Text = "";
        }

        private void button_update_Click(object sender, EventArgs e)
        {
            change();
            ClearFields();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox_id_order_TextChanged(object sender, EventArgs e)
        {
            textBox_id_order.ReadOnly = true;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox_name_good_TextChanged(object sender, EventArgs e)
        {

            textBox_name_good.ReadOnly = true;
        }

        private void textBox_type_of_TextChanged(object sender, EventArgs e)
        {
            textBox_type_of.ReadOnly = true;

        }
    }
}
