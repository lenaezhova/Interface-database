﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class suppliers : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;
        public suppliers()
        {
            InitializeComponent();
        }
        private void LoadData()
        {
            try
            {
                sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Suppliers]", sqlconn);

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Suppliers");

                dataGridView1.DataSource = dataset.Tables["Suppliers"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            try
            {
                dataset.Tables["Suppliers"].Clear();

                sqldataadapter.Fill(dataset, "Suppliers");

                dataGridView1.DataSource = dataset.Tables["Suppliers"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[4, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

     

        private void suppliers_Load(object sender, EventArgs e)
        {

            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 4)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();

                    if (task == "DELETE")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);

                            dataset.Tables["Suppliers"].Rows[rowIndex].Delete();

                            sqldataadapter.Update(dataset, "Suppliers");
                        }
                    }
                    else if (task == "INSERT")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;
                        DataRow row = dataset.Tables["Suppliers"].NewRow();

                        row["Surname"] = dataGridView1.Rows[rowIndex].Cells["Surname"].Value;
                        row["Name_of_supplier"] = dataGridView1.Rows[rowIndex].Cells["Name_of_supplier"].Value;
                        row["Phone_number"] = dataGridView1.Rows[rowIndex].Cells["Phone_number"].Value;
                      
                        dataset.Tables["Suppliers"].Rows.Add(row);
                        dataset.Tables["Suppliers"].Rows.RemoveAt(dataset.Tables["Suppliers"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "DELETE";

                        sqldataadapter.Update(dataset, "Suppliers");
                        newRoading = false;
                    }
                    else if (task == "UPDATE")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Suppliers"].Rows[r]["Surname"] = dataGridView1.Rows[r].Cells["Surname"].Value;
                        dataset.Tables["Suppliers"].Rows[r]["Name_of_supplier"] = dataGridView1.Rows[r].Cells["Name_of_supplier"].Value;
                        dataset.Tables["Suppliers"].Rows[r]["Phone_number"] = dataGridView1.Rows[r].Cells["Phone_number"].Value;

                        sqldataadapter.Update(dataset, "Suppliers");
                        dataGridView1.Rows[e.RowIndex].Cells[4].Value = "DELETE";

                    }
                    ReloadData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {

            try
            {
                if (newRoading == false)
                {
                    newRoading = true;
                    int lastRow = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRow];
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[4, lastRow] = linkcell;

                    row.Cells["Command"].Value = "INSERT";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {

            try
            {
                if (newRoading == false)
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[4, rowIndex] = linkcell;

                    editingrow.Cells["Command"].Value = "UPDATE";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }
    }
}
