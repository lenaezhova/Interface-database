﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class exployees : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;
        public exployees()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            try
            {


                sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Employees]", sqlconn);

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Employees");

                dataGridView1.DataSource = dataset.Tables["Employees"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[7, i] = linkcell;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {

                try
                {
                    dataset.Tables["Employees"].Clear();

                    sqldataadapter.Fill(dataset, "Employees");

                    dataGridView1.DataSource = dataset.Tables["Employees"];

                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                        dataGridView1[7, i] = linkcell;
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            
        }

        private void exployees_Load(object sender, EventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                panel1.Visible = true;
                panel3.Visible = true;
                panel4.Visible = true;

                button1.Visible = false;
                CreateColums();
                RefreshDataGrid(dataGridView1);
            }
            else
            {
                panel1.Visible = false;
                panel3.Visible = false;
                panel4.Visible = false;

                button1.Visible = true;
                string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
                sqlconn = new SqlConnection(connectionString);
                sqlconn.Open();
                LoadData();
            }
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {


                ReloadData();
            
        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
            if (authorization.testOnClickBut != true)
            {
                try
                {

                    if (e.ColumnIndex == 7)
                    {
                        string task = dataGridView1.Rows[e.RowIndex].Cells[7].Value.ToString();

                        if (task == "DELETE")
                        {
                            if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                            {
                                int rowIndex = e.RowIndex;

                                dataGridView1.Rows.RemoveAt(rowIndex);

                                dataset.Tables["Employees"].Rows[rowIndex].Delete();

                                sqldataadapter.Update(dataset, "Employees");
                            }
                        }
                        else if (task == "INSERT")
                        {
                            int rowIndex = dataGridView1.Rows.Count - 2;
                            DataRow row = dataset.Tables["Employees"].NewRow();

                            row["Surname_of_empl"] = dataGridView1.Rows[rowIndex].Cells["Surname_of_empl"].Value;
                            row["Name_of_empl"] = dataGridView1.Rows[rowIndex].Cells["Name_of_empl"].Value;
                            row["Date_of_birth"] = dataGridView1.Rows[rowIndex].Cells["Date_of_birth"].Value;
                            row["Phone_number"] = dataGridView1.Rows[rowIndex].Cells["Phone_number"].Value;
                            row["Post"] = dataGridView1.Rows[rowIndex].Cells["Post"].Value;
                            row["Work_experience"] = dataGridView1.Rows[rowIndex].Cells["Work_experience"].Value;


                            dataset.Tables["Employees"].Rows.Add(row);
                            dataset.Tables["Employees"].Rows.RemoveAt(dataset.Tables["Employees"].Rows.Count - 1);
                            dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                            dataGridView1.Rows[e.RowIndex].Cells[7].Value = "DELETE";

                            sqldataadapter.Update(dataset, "Employees");
                            newRoading = false;
                        }
                        else if (task == "UPDATE")
                        {
                            int r = e.RowIndex;
                            dataset.Tables["Employees"].Rows[r]["Surname_of_empl"] = dataGridView1.Rows[r].Cells["Surname_of_empl"].Value;
                            dataset.Tables["Employees"].Rows[r]["Name_of_empl"] = dataGridView1.Rows[r].Cells["Name_of_empl"].Value;
                            dataset.Tables["Employees"].Rows[r]["Date_of_birth"] = dataGridView1.Rows[r].Cells["Date_of_birth"].Value;
                            dataset.Tables["Employees"].Rows[r]["Phone_number"] = dataGridView1.Rows[r].Cells["Phone_number"].Value;
                            dataset.Tables["Employees"].Rows[r]["Post"] = dataGridView1.Rows[r].Cells["Post"].Value;
                            dataset.Tables["Employees"].Rows[r]["Work_experience"] = dataGridView1.Rows[r].Cells["Work_experience"].Value;


                            sqldataadapter.Update(dataset, "Employees");
                            dataGridView1.Rows[e.RowIndex].Cells[7].Value = "DELETE";

                        }
                        ReloadData();
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {

                try
                {
                    if (newRoading == false)
                    {
                        newRoading = true;
                        int lastRow = dataGridView1.Rows.Count - 2;

                        DataGridViewRow row = dataGridView1.Rows[lastRow];
                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[7, lastRow] = linkcell;

                        row.Cells["Command"].Value = "INSERT";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut != true)
            {

                try
                {
                    if (newRoading == false)
                    {
                        int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                        DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                        DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                        dataGridView1[7, rowIndex] = linkcell;

                        editingrow.Cells["Command"].Value = "UPDATE";
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //настройки для пользователя
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------------------------

        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");


        private void textBox_id_em_TextChanged(object sender, EventArgs e)
        {
            textBox_id_em.ReadOnly = true;

        }

        private void textBox_surname_TextChanged(object sender, EventArgs e)
        {
            textBox_surname.ReadOnly = true;

        }

        private void textBox_name_TextChanged(object sender, EventArgs e)
        {
            textBox_name.ReadOnly = true;

        }

        private void textBox_phone_TextChanged(object sender, EventArgs e)
        {
            textBox_phone.ReadOnly = true;

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            ClearFields();
            RefreshDataGrid(dataGridView1);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (authorization.testOnClickBut == true)
            {
                int selectedRow = e.RowIndex;
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dataGridView1.Rows[selectedRow];
                    textBox_id_em.Text = row.Cells[0].Value.ToString();
                    textBox_surname.Text = row.Cells[1].Value.ToString();
                    textBox_name.Text = row.Cells[2].Value.ToString();
                    textBox_phone.Text = row.Cells[3].Value.ToString();
                }
            }
        }

        private void ClearFields()
        {
            textBox_id_em.Text = "";
            textBox_name.Text = "";
            textBox_phone.Text = "";
            textBox_surname.Text = "";
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("ID_employee", "ID");
            dataGridView1.Columns.Add("Surname_of_empl", "Фамилия сотрудника");
            dataGridView1.Columns.Add("Name_of_empl", "Имя сотрудника");
            dataGridView1.Columns.Add("Phone_number", "Номер телефона");
        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2),
                          record.GetValue(3));


        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = "SELECT ID_employee, Surname_of_empl, Name_of_empl, Phone_number from Employees";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }


        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

            connection.Open();
            SqlCommand com = new SqlCommand(searchString, connection);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();


        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            string searchString = @"SELECT ID_employee, Surname_of_empl, Name_of_empl, Phone_number FROM Employees WHERE CONCAT(ID_employee, Surname_of_empl, Name_of_empl, Phone_number)  LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }
    }
}