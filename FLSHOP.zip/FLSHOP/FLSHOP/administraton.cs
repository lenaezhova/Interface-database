﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class administraton : Form
    {
        public administraton()
        {
            InitializeComponent();
        }



        private void clos_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void clos_MouseEnter(object sender, EventArgs e)
        {
            close.ForeColor = Color.White;

        }

        private void clos_MouseLeave(object sender, EventArgs e)
        {
            System.Drawing.Color col = System.Drawing.ColorTranslator.FromHtml("#aae9d6");
            close.ForeColor = col;
        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            authorization auto = new authorization();
            auto.Show();
        }

        private void FutureForm_Click(object sender, EventArgs e)
        {
            //this.Hide();
            if (clients.Checked)
            {
                clients cl = new clients();
                cl.Show();
            }
            if (orders.Checked)
            {
                orders or = new orders();
                or.Show();
            }
            if (goods.Checked)
            {
                goods oor = new goods();
                oor.Show();
            }
            if (flowers.Checked)
            {
                flowers oor = new flowers();
                oor.Show();
            }
            if (bouqets.Checked)
            {
                boueqts oor = new boueqts();
                oor.Show();
            }
            if (accessories.Checked)
            {
                accessories oor = new accessories();
                oor.Show();
            }
            if (composition_of_accsessories.Checked)
            {
                composition_of_accessories oor = new composition_of_accessories();
                oor.Show();
            }
            if (composition_of_bouquet.Checked)
            {
                composition_of_bouqets oor = new composition_of_bouqets();
                oor.Show();
            }
            if (goods_on_sale.Checked)
            {
                goods_on_sale oor = new goods_on_sale();
                oor.Show();
            }
            if (suppliers.Checked)
            {
                suppliers oor = new suppliers();
                oor.Show();
            }
            if (supply.Checked)
            {
                supply oor = new supply();
                oor.Show();
            }
            if (positions.Checked)
            {
                positions oor = new positions();
                oor.Show();
            }
            if (employees.Checked)
            {
                exployees oor = new exployees();
                oor.Show();
            }
            if (executer_of_order.Checked)
            {
                executer_of_the_order oor = new executer_of_the_order();
                oor.Show();
            }
            if (salary.Checked)
            {
                salary oor = new salary();
                oor.Show();
            }
            if (types_of_goods.Checked)
            {
                types oor = new types();
                oor.Show();
            }

        }

        private void bouqets_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void chose_Click(object sender, EventArgs e)
        {

        }

        private void clients_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void composition_of_bouquet_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void types_of_goods_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
