﻿namespace FLSHOP
{
    partial class suplyForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_order = new System.Windows.Forms.TextBox();
            this.textBox_date = new System.Windows.Forms.TextBox();
            this.textBox_id_good = new System.Windows.Forms.TextBox();
            this.textBox_num = new System.Windows.Forms.TextBox();
            this.surname_client = new System.Windows.Forms.Label();
            this.Name_client = new System.Windows.Forms.Label();
            this.date_order = new System.Windows.Forms.Label();
            this.phone_number = new System.Windows.Forms.Label();
            this.button_save = new System.Windows.Forms.Button();
            this.clos = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel1.Controls.Add(this.textBox_order);
            this.panel1.Controls.Add(this.textBox_date);
            this.panel1.Controls.Add(this.textBox_id_good);
            this.panel1.Controls.Add(this.textBox_num);
            this.panel1.Controls.Add(this.surname_client);
            this.panel1.Controls.Add(this.Name_client);
            this.panel1.Controls.Add(this.date_order);
            this.panel1.Controls.Add(this.phone_number);
            this.panel1.Controls.Add(this.button_save);
            this.panel1.Controls.Add(this.clos);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(448, 310);
            this.panel1.TabIndex = 20;
            // 
            // textBox_order
            // 
            this.textBox_order.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_order.Location = new System.Drawing.Point(222, 179);
            this.textBox_order.Name = "textBox_order";
            this.textBox_order.Size = new System.Drawing.Size(209, 28);
            this.textBox_order.TabIndex = 25;
            // 
            // textBox_date
            // 
            this.textBox_date.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_date.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_date.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_date.Location = new System.Drawing.Point(222, 104);
            this.textBox_date.Name = "textBox_date";
            this.textBox_date.Size = new System.Drawing.Size(209, 28);
            this.textBox_date.TabIndex = 24;
            // 
            // textBox_id_good
            // 
            this.textBox_id_good.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_id_good.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_id_good.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_id_good.Location = new System.Drawing.Point(222, 129);
            this.textBox_id_good.Name = "textBox_id_good";
            this.textBox_id_good.Size = new System.Drawing.Size(209, 28);
            this.textBox_id_good.TabIndex = 23;
            // 
            // textBox_num
            // 
            this.textBox_num.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_num.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_num.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_num.Location = new System.Drawing.Point(222, 154);
            this.textBox_num.Name = "textBox_num";
            this.textBox_num.Size = new System.Drawing.Size(209, 28);
            this.textBox_num.TabIndex = 22;
            // 
            // surname_client
            // 
            this.surname_client.AutoSize = true;
            this.surname_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surname_client.Location = new System.Drawing.Point(18, 104);
            this.surname_client.Name = "surname_client";
            this.surname_client.Size = new System.Drawing.Size(94, 21);
            this.surname_client.TabIndex = 21;
            this.surname_client.Text = "Дата заказа";
            this.surname_client.Click += new System.EventHandler(this.surname_client_Click);
            // 
            // Name_client
            // 
            this.Name_client.AutoSize = true;
            this.Name_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_client.Location = new System.Drawing.Point(19, 131);
            this.Name_client.Name = "Name_client";
            this.Name_client.Size = new System.Drawing.Size(80, 21);
            this.Name_client.TabIndex = 20;
            this.Name_client.Text = "ID товара";
            // 
            // date_order
            // 
            this.date_order.AutoSize = true;
            this.date_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.date_order.Location = new System.Drawing.Point(19, 185);
            this.date_order.Name = "date_order";
            this.date_order.Size = new System.Drawing.Size(50, 21);
            this.date_order.TabIndex = 19;
            this.date_order.Text = "Заказ";
            // 
            // phone_number
            // 
            this.phone_number.AutoSize = true;
            this.phone_number.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.phone_number.Location = new System.Drawing.Point(19, 158);
            this.phone_number.Name = "phone_number";
            this.phone_number.Size = new System.Drawing.Size(97, 21);
            this.phone_number.TabIndex = 18;
            this.phone_number.Text = "Количество";
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(155, 258);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 17;
            this.button_save.Text = "Заказать";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(420, -1);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label9.Font = new System.Drawing.Font("Candara", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(48, -14);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(366, 63);
            this.label9.TabIndex = 8;
            this.label9.Text = "Введите данные:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // suplyForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(448, 310);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "suplyForm";
            this.Text = "suplyForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_order;
        private System.Windows.Forms.TextBox textBox_date;
        private System.Windows.Forms.TextBox textBox_id_good;
        private System.Windows.Forms.TextBox textBox_num;
        private System.Windows.Forms.Label surname_client;
        private System.Windows.Forms.Label Name_client;
        private System.Windows.Forms.Label date_order;
        private System.Windows.Forms.Label phone_number;
    }
}