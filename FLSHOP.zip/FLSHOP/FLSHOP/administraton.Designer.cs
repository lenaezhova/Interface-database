﻿namespace FLSHOP
{
    partial class administraton
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.FutureForm = new System.Windows.Forms.Button();
            this.returnBack = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.clos = new System.Windows.Forms.Label();
            this.chose = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.types_of_goods = new System.Windows.Forms.CheckBox();
            this.supply = new System.Windows.Forms.CheckBox();
            this.salary = new System.Windows.Forms.CheckBox();
            this.suppliers = new System.Windows.Forms.CheckBox();
            this.goods_on_sale = new System.Windows.Forms.CheckBox();
            this.positions = new System.Windows.Forms.CheckBox();
            this.executer_of_order = new System.Windows.Forms.CheckBox();
            this.employees = new System.Windows.Forms.CheckBox();
            this.composition_of_bouquet = new System.Windows.Forms.CheckBox();
            this.composition_of_accsessories = new System.Windows.Forms.CheckBox();
            this.accessories = new System.Windows.Forms.CheckBox();
            this.bouqets = new System.Windows.Forms.CheckBox();
            this.flowers = new System.Windows.Forms.CheckBox();
            this.goods = new System.Windows.Forms.CheckBox();
            this.orders = new System.Windows.Forms.CheckBox();
            this.clients = new System.Windows.Forms.CheckBox();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.FutureForm);
            this.panel2.Controls.Add(this.returnBack);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 544);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(635, 88);
            this.panel2.TabIndex = 5;
            // 
            // FutureForm
            // 
            this.FutureForm.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.FutureForm.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.FutureForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.FutureForm.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.FutureForm.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.FutureForm.Location = new System.Drawing.Point(429, 31);
            this.FutureForm.Name = "FutureForm";
            this.FutureForm.Size = new System.Drawing.Size(174, 35);
            this.FutureForm.TabIndex = 11;
            this.FutureForm.Text = "Далее";
            this.FutureForm.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.FutureForm.UseVisualStyleBackColor = false;
            this.FutureForm.Click += new System.EventHandler(this.FutureForm_Click);
            // 
            // returnBack
            // 
            this.returnBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.returnBack.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.returnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.returnBack.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.returnBack.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.returnBack.Location = new System.Drawing.Point(11, 31);
            this.returnBack.Name = "returnBack";
            this.returnBack.Size = new System.Drawing.Size(174, 35);
            this.returnBack.TabIndex = 4;
            this.returnBack.Text = "Вернуться назад";
            this.returnBack.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.returnBack.UseVisualStyleBackColor = false;
            this.returnBack.Click += new System.EventHandler(this.returnBack_Click);
            // 
            // close
            // 
            this.close.AutoSize = true;
            this.close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.close.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.close.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.close.Location = new System.Drawing.Point(406, -1);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(29, 35);
            this.close.TabIndex = 6;
            this.close.Text = "x";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.clos);
            this.panel3.Controls.Add(this.chose);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(635, 87);
            this.panel3.TabIndex = 9;
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(606, 0);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 10;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            this.clos.MouseEnter += new System.EventHandler(this.clos_MouseEnter);
            this.clos.MouseLeave += new System.EventHandler(this.clos_MouseLeave);
            // 
            // chose
            // 
            this.chose.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chose.Font = new System.Drawing.Font("Candara Light", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.chose.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.chose.Location = new System.Drawing.Point(0, 0);
            this.chose.Name = "chose";
            this.chose.Size = new System.Drawing.Size(635, 87);
            this.chose.TabIndex = 8;
            this.chose.Text = "Выберите таблицу для просмотра";
            this.chose.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chose.Click += new System.EventHandler(this.chose_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.types_of_goods);
            this.panel1.Controls.Add(this.supply);
            this.panel1.Controls.Add(this.salary);
            this.panel1.Controls.Add(this.suppliers);
            this.panel1.Controls.Add(this.goods_on_sale);
            this.panel1.Controls.Add(this.positions);
            this.panel1.Controls.Add(this.executer_of_order);
            this.panel1.Controls.Add(this.employees);
            this.panel1.Controls.Add(this.composition_of_bouquet);
            this.panel1.Controls.Add(this.composition_of_accsessories);
            this.panel1.Controls.Add(this.accessories);
            this.panel1.Controls.Add(this.bouqets);
            this.panel1.Controls.Add(this.flowers);
            this.panel1.Controls.Add(this.goods);
            this.panel1.Controls.Add(this.orders);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.clients);
            this.panel1.Controls.Add(this.close);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(637, 634);
            this.panel1.TabIndex = 2;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // types_of_goods
            // 
            this.types_of_goods.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.types_of_goods.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.types_of_goods.Location = new System.Drawing.Point(336, 345);
            this.types_of_goods.Name = "types_of_goods";
            this.types_of_goods.Size = new System.Drawing.Size(242, 27);
            this.types_of_goods.TabIndex = 26;
            this.types_of_goods.Text = "Типы товаров";
            this.types_of_goods.UseVisualStyleBackColor = true;
            this.types_of_goods.CheckedChanged += new System.EventHandler(this.types_of_goods_CheckedChanged);
            // 
            // supply
            // 
            this.supply.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.supply.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.supply.Location = new System.Drawing.Point(336, 312);
            this.supply.Name = "supply";
            this.supply.Size = new System.Drawing.Size(288, 27);
            this.supply.TabIndex = 24;
            this.supply.Text = "Доставка от поставщиков";
            this.supply.UseVisualStyleBackColor = true;
            // 
            // salary
            // 
            this.salary.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.salary.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.salary.Location = new System.Drawing.Point(336, 247);
            this.salary.Name = "salary";
            this.salary.Size = new System.Drawing.Size(214, 27);
            this.salary.TabIndex = 23;
            this.salary.Text = "Зарплата";
            this.salary.UseVisualStyleBackColor = true;
            // 
            // suppliers
            // 
            this.suppliers.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.suppliers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.suppliers.Location = new System.Drawing.Point(336, 280);
            this.suppliers.Name = "suppliers";
            this.suppliers.Size = new System.Drawing.Size(214, 27);
            this.suppliers.TabIndex = 22;
            this.suppliers.Text = "Поставщики";
            this.suppliers.UseVisualStyleBackColor = true;
            // 
            // goods_on_sale
            // 
            this.goods_on_sale.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.goods_on_sale.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.goods_on_sale.Location = new System.Drawing.Point(60, 345);
            this.goods_on_sale.Name = "goods_on_sale";
            this.goods_on_sale.Size = new System.Drawing.Size(214, 27);
            this.goods_on_sale.TabIndex = 21;
            this.goods_on_sale.Text = "Товары в продаже";
            this.goods_on_sale.UseVisualStyleBackColor = true;
            // 
            // positions
            // 
            this.positions.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.positions.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.positions.Location = new System.Drawing.Point(336, 214);
            this.positions.Name = "positions";
            this.positions.Size = new System.Drawing.Size(214, 27);
            this.positions.TabIndex = 20;
            this.positions.Text = "Должности";
            this.positions.UseVisualStyleBackColor = true;
            // 
            // executer_of_order
            // 
            this.executer_of_order.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.executer_of_order.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.executer_of_order.Location = new System.Drawing.Point(60, 181);
            this.executer_of_order.Name = "executer_of_order";
            this.executer_of_order.Size = new System.Drawing.Size(214, 27);
            this.executer_of_order.TabIndex = 18;
            this.executer_of_order.Text = "Исполнитель заказа";
            this.executer_of_order.UseVisualStyleBackColor = true;
            // 
            // employees
            // 
            this.employees.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.employees.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.employees.Location = new System.Drawing.Point(336, 181);
            this.employees.Name = "employees";
            this.employees.Size = new System.Drawing.Size(214, 27);
            this.employees.TabIndex = 17;
            this.employees.Text = "Сотрудники";
            this.employees.UseVisualStyleBackColor = true;
            // 
            // composition_of_bouquet
            // 
            this.composition_of_bouquet.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.composition_of_bouquet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.composition_of_bouquet.Location = new System.Drawing.Point(336, 114);
            this.composition_of_bouquet.Name = "composition_of_bouquet";
            this.composition_of_bouquet.Size = new System.Drawing.Size(254, 27);
            this.composition_of_bouquet.TabIndex = 16;
            this.composition_of_bouquet.Text = "Композиция букета";
            this.composition_of_bouquet.UseVisualStyleBackColor = true;
            this.composition_of_bouquet.CheckedChanged += new System.EventHandler(this.composition_of_bouquet_CheckedChanged);
            // 
            // composition_of_accsessories
            // 
            this.composition_of_accsessories.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.composition_of_accsessories.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.composition_of_accsessories.Location = new System.Drawing.Point(336, 147);
            this.composition_of_accsessories.Name = "composition_of_accsessories";
            this.composition_of_accsessories.Size = new System.Drawing.Size(288, 27);
            this.composition_of_accsessories.TabIndex = 15;
            this.composition_of_accsessories.Text = "Композиция аксесcуаров";
            this.composition_of_accsessories.UseVisualStyleBackColor = true;
            // 
            // accessories
            // 
            this.accessories.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.accessories.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.accessories.Location = new System.Drawing.Point(60, 312);
            this.accessories.Name = "accessories";
            this.accessories.Size = new System.Drawing.Size(214, 27);
            this.accessories.TabIndex = 14;
            this.accessories.Text = "Аксессуары";
            this.accessories.UseVisualStyleBackColor = true;
            // 
            // bouqets
            // 
            this.bouqets.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bouqets.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.bouqets.Location = new System.Drawing.Point(60, 279);
            this.bouqets.Name = "bouqets";
            this.bouqets.Size = new System.Drawing.Size(214, 27);
            this.bouqets.TabIndex = 13;
            this.bouqets.Text = "Букеты";
            this.bouqets.UseVisualStyleBackColor = true;
            this.bouqets.CheckedChanged += new System.EventHandler(this.bouqets_CheckedChanged);
            // 
            // flowers
            // 
            this.flowers.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.flowers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.flowers.Location = new System.Drawing.Point(60, 246);
            this.flowers.Name = "flowers";
            this.flowers.Size = new System.Drawing.Size(214, 27);
            this.flowers.TabIndex = 12;
            this.flowers.Text = "Цветы";
            this.flowers.UseVisualStyleBackColor = true;
            // 
            // goods
            // 
            this.goods.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.goods.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.goods.Location = new System.Drawing.Point(60, 213);
            this.goods.Name = "goods";
            this.goods.Size = new System.Drawing.Size(214, 27);
            this.goods.TabIndex = 11;
            this.goods.Text = "Товары";
            this.goods.UseVisualStyleBackColor = true;
            // 
            // orders
            // 
            this.orders.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.orders.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.orders.Location = new System.Drawing.Point(60, 147);
            this.orders.Name = "orders";
            this.orders.Size = new System.Drawing.Size(214, 27);
            this.orders.TabIndex = 10;
            this.orders.Text = "Заказы";
            this.orders.UseVisualStyleBackColor = true;
            // 
            // clients
            // 
            this.clients.Font = new System.Drawing.Font("Candara Light", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.clients.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clients.Location = new System.Drawing.Point(60, 114);
            this.clients.Name = "clients";
            this.clients.Size = new System.Drawing.Size(214, 27);
            this.clients.TabIndex = 7;
            this.clients.Text = "Клиенты";
            this.clients.UseVisualStyleBackColor = true;
            this.clients.CheckedChanged += new System.EventHandler(this.clients_CheckedChanged);
            // 
            // administraton
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 634);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "administraton";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "administraton";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button FutureForm;
        private System.Windows.Forms.Button returnBack;
        private System.Windows.Forms.Label close;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.Label chose;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox executer_of_order;
        private System.Windows.Forms.CheckBox employees;
        private System.Windows.Forms.CheckBox composition_of_bouquet;
        private System.Windows.Forms.CheckBox composition_of_accsessories;
        private System.Windows.Forms.CheckBox accessories;
        private System.Windows.Forms.CheckBox bouqets;
        private System.Windows.Forms.CheckBox flowers;
        private System.Windows.Forms.CheckBox goods;
        private System.Windows.Forms.CheckBox orders;
        private System.Windows.Forms.CheckBox clients;
        private System.Windows.Forms.CheckBox supply;
        private System.Windows.Forms.CheckBox salary;
        private System.Windows.Forms.CheckBox suppliers;
        private System.Windows.Forms.CheckBox goods_on_sale;
        private System.Windows.Forms.CheckBox positions;
        private System.Windows.Forms.CheckBox types_of_goods;
    }
}