﻿namespace FLSHOP
{
    partial class clientsorder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_delete = new System.Windows.Forms.Button();
            this.button_update = new System.Windows.Forms.Button();
            this.button_save = new System.Windows.Forms.Button();
            this.button_newWrite = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox_bonus = new System.Windows.Forms.TextBox();
            this.textBox_date_order = new System.Windows.Forms.TextBox();
            this.textBox_cost = new System.Windows.Forms.TextBox();
            this.textBox_surname_of_empl = new System.Windows.Forms.TextBox();
            this.textBox_surname_client = new System.Windows.Forms.TextBox();
            this.textBox_name_client = new System.Windows.Forms.TextBox();
            this.textBox_phone_number = new System.Windows.Forms.TextBox();
            this.textBox_id_order = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.surname_of_empl = new System.Windows.Forms.Label();
            this.surname_client = new System.Windows.Forms.Label();
            this.Name_client = new System.Windows.Forms.Label();
            this.cost = new System.Windows.Forms.Label();
            this.bonus = new System.Windows.Forms.Label();
            this.date_order = new System.Windows.Forms.Label();
            this.id_order = new System.Windows.Forms.Label();
            this.phone_number = new System.Windows.Forms.Label();
            this.search = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.clos = new System.Windows.Forms.Label();
            this.textBox_id_client = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel1);
            this.panel2.Controls.Add(this.search);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.clos);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(680, 680);
            this.panel2.TabIndex = 4;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.button_delete);
            this.panel3.Controls.Add(this.button_update);
            this.panel3.Controls.Add(this.button_save);
            this.panel3.Controls.Add(this.button_newWrite);
            this.panel3.Location = new System.Drawing.Point(480, 367);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(188, 286);
            this.panel3.TabIndex = 19;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(20, 92);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 33);
            this.button1.TabIndex = 18;
            this.button1.Text = "Обновить";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(29, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 24);
            this.label1.TabIndex = 17;
            this.label1.Text = "Управление";
            // 
            // button_delete
            // 
            this.button_delete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_delete.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_delete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_delete.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_delete.Location = new System.Drawing.Point(20, 179);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(150, 33);
            this.button_delete.TabIndex = 16;
            this.button_delete.Text = "Удалить";
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // button_update
            // 
            this.button_update.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_update.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_update.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_update.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_update.Location = new System.Drawing.Point(20, 135);
            this.button_update.Name = "button_update";
            this.button_update.Size = new System.Drawing.Size(150, 33);
            this.button_update.TabIndex = 15;
            this.button_update.Text = "Изменить";
            this.button_update.UseVisualStyleBackColor = false;
            this.button_update.Click += new System.EventHandler(this.button_update_Click);
            // 
            // button_save
            // 
            this.button_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_save.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_save.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_save.Location = new System.Drawing.Point(20, 222);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(150, 33);
            this.button_save.TabIndex = 14;
            this.button_save.Text = "Сохранить";
            this.button_save.UseVisualStyleBackColor = false;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // button_newWrite
            // 
            this.button_newWrite.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(176)))), ((int)(((byte)(225)))));
            this.button_newWrite.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.button_newWrite.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_newWrite.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_newWrite.Location = new System.Drawing.Point(20, 47);
            this.button_newWrite.Name = "button_newWrite";
            this.button_newWrite.Size = new System.Drawing.Size(150, 33);
            this.button_newWrite.TabIndex = 13;
            this.button_newWrite.Text = "Новая запись";
            this.button_newWrite.UseVisualStyleBackColor = false;
            this.button_newWrite.Click += new System.EventHandler(this.button_newWrite_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox_id_client);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox_bonus);
            this.panel1.Controls.Add(this.textBox_date_order);
            this.panel1.Controls.Add(this.textBox_cost);
            this.panel1.Controls.Add(this.textBox_surname_of_empl);
            this.panel1.Controls.Add(this.textBox_surname_client);
            this.panel1.Controls.Add(this.textBox_name_client);
            this.panel1.Controls.Add(this.textBox_phone_number);
            this.panel1.Controls.Add(this.textBox_id_order);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.surname_of_empl);
            this.panel1.Controls.Add(this.surname_client);
            this.panel1.Controls.Add(this.Name_client);
            this.panel1.Controls.Add(this.cost);
            this.panel1.Controls.Add(this.bonus);
            this.panel1.Controls.Add(this.date_order);
            this.panel1.Controls.Add(this.id_order);
            this.panel1.Controls.Add(this.phone_number);
            this.panel1.Location = new System.Drawing.Point(12, 367);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(449, 286);
            this.panel1.TabIndex = 18;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // textBox_bonus
            // 
            this.textBox_bonus.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_bonus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_bonus.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_bonus.Location = new System.Drawing.Point(222, 170);
            this.textBox_bonus.Name = "textBox_bonus";
            this.textBox_bonus.Size = new System.Drawing.Size(209, 28);
            this.textBox_bonus.TabIndex = 16;
            this.textBox_bonus.TextChanged += new System.EventHandler(this.textBox_bonus_TextChanged);
            // 
            // textBox_date_order
            // 
            this.textBox_date_order.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_date_order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_date_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_date_order.Location = new System.Drawing.Point(222, 195);
            this.textBox_date_order.Name = "textBox_date_order";
            this.textBox_date_order.Size = new System.Drawing.Size(209, 28);
            this.textBox_date_order.TabIndex = 15;
            // 
            // textBox_cost
            // 
            this.textBox_cost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_cost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_cost.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_cost.Location = new System.Drawing.Point(222, 220);
            this.textBox_cost.Name = "textBox_cost";
            this.textBox_cost.Size = new System.Drawing.Size(209, 28);
            this.textBox_cost.TabIndex = 14;
            this.textBox_cost.TextChanged += new System.EventHandler(this.textBox_cost_TextChanged);
            // 
            // textBox_surname_of_empl
            // 
            this.textBox_surname_of_empl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_surname_of_empl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_surname_of_empl.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_surname_of_empl.Location = new System.Drawing.Point(222, 245);
            this.textBox_surname_of_empl.Name = "textBox_surname_of_empl";
            this.textBox_surname_of_empl.Size = new System.Drawing.Size(209, 28);
            this.textBox_surname_of_empl.TabIndex = 13;
            // 
            // textBox_surname_client
            // 
            this.textBox_surname_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_surname_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_surname_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_surname_client.Location = new System.Drawing.Point(222, 95);
            this.textBox_surname_client.Name = "textBox_surname_client";
            this.textBox_surname_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_surname_client.TabIndex = 12;
            // 
            // textBox_name_client
            // 
            this.textBox_name_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_name_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_name_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_name_client.Location = new System.Drawing.Point(222, 120);
            this.textBox_name_client.Name = "textBox_name_client";
            this.textBox_name_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_name_client.TabIndex = 11;
            // 
            // textBox_phone_number
            // 
            this.textBox_phone_number.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_phone_number.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_phone_number.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_phone_number.Location = new System.Drawing.Point(222, 145);
            this.textBox_phone_number.Name = "textBox_phone_number";
            this.textBox_phone_number.Size = new System.Drawing.Size(209, 28);
            this.textBox_phone_number.TabIndex = 10;
            // 
            // textBox_id_order
            // 
            this.textBox_id_order.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_id_order.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_id_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_id_order.Location = new System.Drawing.Point(222, 46);
            this.textBox_id_order.Name = "textBox_id_order";
            this.textBox_id_order.Size = new System.Drawing.Size(209, 28);
            this.textBox_id_order.TabIndex = 9;
            this.textBox_id_order.TextChanged += new System.EventHandler(this.textBox_id_order_TextChanged);
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(172, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(92, 24);
            this.label9.TabIndex = 8;
            this.label9.Text = "Запись";
            // 
            // surname_of_empl
            // 
            this.surname_of_empl.AutoSize = true;
            this.surname_of_empl.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.surname_of_empl.Location = new System.Drawing.Point(19, 252);
            this.surname_of_empl.Name = "surname_of_empl";
            this.surname_of_empl.Size = new System.Drawing.Size(171, 21);
            this.surname_of_empl.TabIndex = 7;
            this.surname_of_empl.Text = "Фамилия исполнителя";
            // 
            // surname_client
            // 
            this.surname_client.AutoSize = true;
            this.surname_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surname_client.Location = new System.Drawing.Point(19, 102);
            this.surname_client.Name = "surname_client";
            this.surname_client.Size = new System.Drawing.Size(136, 21);
            this.surname_client.TabIndex = 6;
            this.surname_client.Text = "Фамилия клиента";
            // 
            // Name_client
            // 
            this.Name_client.AutoSize = true;
            this.Name_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name_client.Location = new System.Drawing.Point(19, 127);
            this.Name_client.Name = "Name_client";
            this.Name_client.Size = new System.Drawing.Size(102, 21);
            this.Name_client.TabIndex = 5;
            this.Name_client.Text = "Имя клиента";
            // 
            // cost
            // 
            this.cost.AutoSize = true;
            this.cost.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.cost.Location = new System.Drawing.Point(19, 227);
            this.cost.Name = "cost";
            this.cost.Size = new System.Drawing.Size(93, 21);
            this.cost.TabIndex = 4;
            this.cost.Text = "Стоимость ";
            // 
            // bonus
            // 
            this.bonus.AutoSize = true;
            this.bonus.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bonus.Location = new System.Drawing.Point(19, 177);
            this.bonus.Name = "bonus";
            this.bonus.Size = new System.Drawing.Size(62, 21);
            this.bonus.TabIndex = 3;
            this.bonus.Text = "Скидка";
            // 
            // date_order
            // 
            this.date_order.AutoSize = true;
            this.date_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.date_order.Location = new System.Drawing.Point(19, 202);
            this.date_order.Name = "date_order";
            this.date_order.Size = new System.Drawing.Size(94, 21);
            this.date_order.TabIndex = 2;
            this.date_order.Text = "Дата заказа";
            // 
            // id_order
            // 
            this.id_order.AutoSize = true;
            this.id_order.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.id_order.Location = new System.Drawing.Point(19, 52);
            this.id_order.Name = "id_order";
            this.id_order.Size = new System.Drawing.Size(110, 21);
            this.id_order.TabIndex = 0;
            this.id_order.Text = "Номер заказа";
            // 
            // phone_number
            // 
            this.phone_number.AutoSize = true;
            this.phone_number.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.phone_number.Location = new System.Drawing.Point(19, 152);
            this.phone_number.Name = "phone_number";
            this.phone_number.Size = new System.Drawing.Size(135, 21);
            this.phone_number.TabIndex = 1;
            this.phone_number.Text = "Номер телефона";
            // 
            // search
            // 
            this.search.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.search.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.search.Location = new System.Drawing.Point(45, 13);
            this.search.Multiline = true;
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(128, 22);
            this.search.TabIndex = 17;
            this.search.TextChanged += new System.EventHandler(this.search_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(87, 84);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(507, 277);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // clos
            // 
            this.clos.AutoSize = true;
            this.clos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.clos.Font = new System.Drawing.Font("Candara Light", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(170)))), ((int)(((byte)(233)))), ((int)(((byte)(214)))));
            this.clos.Location = new System.Drawing.Point(651, 0);
            this.clos.Name = "clos";
            this.clos.Size = new System.Drawing.Size(29, 35);
            this.clos.TabIndex = 11;
            this.clos.Text = "x";
            this.clos.Click += new System.EventHandler(this.clos_Click);
            // 
            // textBox_id_client
            // 
            this.textBox_id_client.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(115)))), ((int)(((byte)(211)))));
            this.textBox_id_client.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_id_client.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox_id_client.Location = new System.Drawing.Point(222, 70);
            this.textBox_id_client.Name = "textBox_id_client";
            this.textBox_id_client.Size = new System.Drawing.Size(209, 28);
            this.textBox_id_client.TabIndex = 18;
            this.textBox_id_client.TextChanged += new System.EventHandler(this.textBox_id_client_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara Light", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(19, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 21);
            this.label2.TabIndex = 17;
            this.label2.Text = "Номер клиента";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::FLSHOP.Properties.Resources._370082_find_search_zoom_magnifier_view_icon;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(27, 23);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // clientsorder
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 680);
            this.Controls.Add(this.panel2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "clientsorder";
            this.Text = "clientsorder";
            this.Load += new System.EventHandler(this.clientsorder_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_newWrite;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label clos;
        private System.Windows.Forms.TextBox search;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label surname_of_empl;
        private System.Windows.Forms.Label surname_client;
        private System.Windows.Forms.Label Name_client;
        private System.Windows.Forms.Label cost;
        private System.Windows.Forms.Label bonus;
        private System.Windows.Forms.Label date_order;
        private System.Windows.Forms.Label phone_number;
        private System.Windows.Forms.Label id_order;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_id_order;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox textBox_bonus;
        private System.Windows.Forms.TextBox textBox_date_order;
        private System.Windows.Forms.TextBox textBox_cost;
        private System.Windows.Forms.TextBox textBox_surname_of_empl;
        private System.Windows.Forms.TextBox textBox_surname_client;
        private System.Windows.Forms.TextBox textBox_name_client;
        private System.Windows.Forms.TextBox textBox_phone_number;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.Button button_update;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox_id_client;
        private System.Windows.Forms.Label label2;
    }
}