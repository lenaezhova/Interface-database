﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    //enum RowState
    //{
    //    Existed,
    //    New, 
    //    ModifiedNew,
    //    Delected   
    //}
    public partial class goodsOnSaleView : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False");

        public goodsOnSaleView()
        {
            InitializeComponent();
        }

        private void goodsOnSaleView_Load(object sender, EventArgs e)
        {
            CreateColums();
            RefreshDataGrid(dataGridView1);
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (connection != null && connection.State != ConnectionState.Closed) connection.Close();
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedRow = e.RowIndex;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];
                textBox_name_good.Text = row.Cells[0].Value.ToString();
                textBox_type_good.Text = row.Cells[1].Value.ToString();
                textBox_num.Text = row.Cells[2].Value.ToString();
            }
        }

        private void textBox_name_good_TextChanged(object sender, EventArgs e)
        {
            textBox_name_good.ReadOnly = true;

        }

        private void textBox_type_good_TextChanged(object sender, EventArgs e)
        {
            textBox_type_good.ReadOnly = true;

        }

        private void textBox_num_TextChanged(object sender, EventArgs e)
        {
            textBox_num.ReadOnly = true;

        }

        private void button_newWrite_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_update_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button_save_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Эта операция недоступна для Вас!", "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ClearFields();
            RefreshDataGrid(dataGridView1);
        }

        private void ClearFields()
        {
            textBox_name_good.Text = "";
            textBox_type_good.Text = "";
            textBox_num.Text = "";
        }

        private void CreateColums()
        {
            dataGridView1.Columns.Add("Name_good", "Название товара");
            dataGridView1.Columns.Add("Type_of", "тип товара");
            dataGridView1.Columns.Add("Number_of_goods", "Актуальное количество");

        }

        private void ReadSingleRow(DataGridView dgv, IDataRecord record)
        {
            dgv.Rows.Add(record.GetValue(0),
                          record.GetValue(1),
                          record.GetValue(2));


        }

        private void RefreshDataGrid(DataGridView dgv)
        {
            dgv.Rows.Clear();

            string queryString = "SELECT * FROM goodsOnSale";
            SqlCommand command = new SqlCommand(queryString, connection);

            connection.Open();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();
        }


        private void sssearch(DataGridView dgv, string searchString)
        {
            dgv.Rows.Clear();

            connection.Open();
            SqlCommand com = new SqlCommand(searchString, connection);
            SqlDataReader reader = com.ExecuteReader();
            while (reader.Read())
            {
                ReadSingleRow(dgv, reader);
            }
            reader.Close();
            connection.Close();


        }

        private void search_TextChanged(object sender, EventArgs e)
        {
            string searchString = @"SELECT * FROM goodsOnSale WHERE CONCAT(Name_good, Type_of, Number_of_goods)  LIKE '%" + search.Text + "%'";

            sssearch(dataGridView1, searchString);
        }
    }

}

