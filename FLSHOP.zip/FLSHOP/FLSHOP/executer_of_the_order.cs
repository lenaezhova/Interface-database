﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class executer_of_the_order : Form
    {
        private SqlConnection sqlconn = null;
        private SqlCommandBuilder sqlbuild = null;
        private SqlDataAdapter sqldataadapter = null;
        private DataSet dataset = null;

        private bool newRoading = false;
        public executer_of_the_order()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            try
            {
                sqldataadapter = new SqlDataAdapter("SELECT *, 'DELETE' AS [Command] FROM [Executer_of_the_order]", sqlconn);

                sqlbuild = new SqlCommandBuilder(sqldataadapter);
                sqlbuild.GetInsertCommand();
                sqlbuild.GetUpdateCommand();
                sqlbuild.GetDeleteCommand();

                dataset = new DataSet();
                sqldataadapter.Fill(dataset, "Executer_of_the_order");

                dataGridView1.DataSource = dataset.Tables["Executer_of_the_order"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[2, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void ReloadData()
        {
            try
            {
                dataset.Tables["Executer_of_the_order"].Clear();

                sqldataadapter.Fill(dataset, "Executer_of_the_order");

                dataGridView1.DataSource = dataset.Tables["Executer_of_the_order"];

                for (int i = 0; i < dataGridView1.Rows.Count; i++)
                {
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();
                    dataGridView1[2, i] = linkcell;
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void executer_of_the_order_Load(object sender, EventArgs e)
        {
            string connectionString = @"Data Source = ELENA; Initial Catalog = Flower_shop; Integrated Security = True; Connect Timeout = 30; Encrypt = False; TrustServerCertificate = False; ApplicationIntent = ReadWrite; MultiSubnetFailover = False";
            sqlconn = new SqlConnection(connectionString);
            sqlconn.Open();
            LoadData();
        }

        private void clos_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReloadData();

        }

        private void returnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            administraton adm = new administraton();
            adm.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.ColumnIndex == 2)
                {
                    string task = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();

                    if (task == "DELETE")
                    {
                        if (MessageBox.Show("Удалить эту строку?", "Удаление", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            int rowIndex = e.RowIndex;

                            dataGridView1.Rows.RemoveAt(rowIndex);

                            dataset.Tables["Executer_of_the_order"].Rows[rowIndex].Delete();

                            sqldataadapter.Update(dataset, "Executer_of_the_order");
                        }
                    }
                    else if (task == "INSERT")
                    {
                        int rowIndex = dataGridView1.Rows.Count - 2;
                        DataRow row = dataset.Tables["Executer_of_the_order"].NewRow();

                        row["OrderID"] = dataGridView1.Rows[rowIndex].Cells["OrderID"].Value;
                        row["EmployeeID"] = dataGridView1.Rows[rowIndex].Cells["EmployeeID"].Value;


                        dataset.Tables["Executer_of_the_order"].Rows.Add(row);
                        dataset.Tables["Executer_of_the_order"].Rows.RemoveAt(dataset.Tables["Executer_of_the_order"].Rows.Count - 1);
                        dataGridView1.Rows.RemoveAt(dataGridView1.Rows.Count - 2);
                        dataGridView1.Rows[e.RowIndex].Cells[2].Value = "DELETE";

                        sqldataadapter.Update(dataset, "Executer_of_the_order");
                        newRoading = false;
                    }
                    else if (task == "UPDATE")
                    {
                        int r = e.RowIndex;
                        dataset.Tables["Executer_of_the_order"].Rows[r]["OrderID"] = dataGridView1.Rows[r].Cells["OrderID"].Value;
                        dataset.Tables["Executer_of_the_order"].Rows[r]["EmployeeID"] = dataGridView1.Rows[r].Cells["EmployeeID"].Value;

                        sqldataadapter.Update(dataset, "Executer_of_the_order");
                        dataGridView1.Rows[e.RowIndex].Cells[2].Value = "DELETE";

                    }
                    ReloadData();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {

            try
            {
                if (newRoading == false)
                {
                    newRoading = true;
                    int lastRow = dataGridView1.Rows.Count - 2;

                    DataGridViewRow row = dataGridView1.Rows[lastRow];
                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[2, lastRow] = linkcell;

                    row.Cells["Command"].Value = "INSERT";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (newRoading == false)
                {
                    int rowIndex = dataGridView1.SelectedCells[0].RowIndex;

                    DataGridViewRow editingrow = dataGridView1.Rows[rowIndex];

                    DataGridViewLinkCell linkcell = new DataGridViewLinkCell();

                    dataGridView1[2, rowIndex] = linkcell;

                    editingrow.Cells["Command"].Value = "UPDATE";
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (sqlconn != null && sqlconn.State != ConnectionState.Closed) sqlconn.Close();
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
