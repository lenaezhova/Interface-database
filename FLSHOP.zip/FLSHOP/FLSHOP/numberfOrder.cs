﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FLSHOP
{
    public partial class numberfOrder : Form
    {
        public static int id_order;

        public numberfOrder()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            goodsINOrdersView add = new goodsINOrdersView();
            add.Show();
        }

        private void button_save_Click(object sender, EventArgs e)
        {
            if (textBox_id_order.Text.Length > 0)
            {
                id_order = Convert.ToInt32(textBox_id_order.Text);
                this.Hide();
                newGoodsInOrder add = new newGoodsInOrder();
                add.Show();
            }
        }

        private void textBox_name_client_TextChanged(object sender, EventArgs e)
        {

        }

        private void clos_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
